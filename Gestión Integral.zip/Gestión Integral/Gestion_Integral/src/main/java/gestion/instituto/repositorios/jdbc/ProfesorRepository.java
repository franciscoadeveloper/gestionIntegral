package gestion.instituto.repositorios.jdbc;

import gestion.instituto.entities.Profesor;
import gestion.instituto.repositorios.interfaces.I_ProfesorRepository;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ProfesorRepository implements I_ProfesorRepository{
    
    private Connection conn;

    public ProfesorRepository(Connection conn) {this.conn = conn;}
    
    @Override
    public void save(Profesor profesor) {
        if(profesor==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
        "insert into profesores (nombre,apellido,dni,cuil,celular,telefonoFijo,email,id_filial) "
                + "values (?,?,?,?,?,?,?,?)",PreparedStatement.RETURN_GENERATED_KEYS)){
            ps.setString(1, profesor.getNombre());
            ps.setString(2, profesor.getApellido());
            ps.setString(3, profesor.getDni());
            ps.setString(4, profesor.getCuil());
            ps.setString(5, profesor.getCelular());
            ps.setString(6, profesor.getTelefonoFijo());
            ps.setString(7, profesor.getEmail());
            ps.setInt(8, profesor.getId_filial());
            ps.execute();
            ResultSet rs=ps.getGeneratedKeys();
            if(rs.next()) profesor.setId(rs.getInt(1));            
        } catch (Exception e) {e.printStackTrace();}
    }

    @Override
    public void remove(Profesor profesor) {
        if(profesor==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
        "delete from profesores where id=?")){
            ps.setInt(1, profesor.getId());
            ps.execute();
        } catch (Exception e) {e.printStackTrace();}
    }

    @Override
    public void update(Profesor profesor) {
        if(profesor==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
        "update profesores set nombre=?, apellido=?, dni=?, cuil=?, celular=?, telefonoFijo=?, "
                + "email=?, id_filial=? where id=?")){
            ps.setString(1, profesor.getNombre());
            ps.setString(2, profesor.getApellido());
            ps.setString(3, profesor.getDni());
            ps.setString(4, profesor.getCuil());
            ps.setString(5, profesor.getCelular());
            ps.setString(6, profesor.getTelefonoFijo());
            ps.setString(7, profesor.getEmail());
            ps.setInt(8, profesor.getId_filial());
            ps.setInt(9, profesor.getId());
            ps.execute();
        } catch (Exception e) {e.printStackTrace();}
    }

    @Override
    public List<Profesor> getAll() {
        List<Profesor>list=new ArrayList();
        try (ResultSet rs=conn.createStatement().executeQuery("select * from profesores")){
            while(rs.next()){
                list.add(new Profesor(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getString("dni"), 
                        rs.getString("cuil"), 
                        rs.getString("celular"), 
                        rs.getString("telefonoFijo"), 
                        rs.getString("email"), 
                        rs.getInt("id_filial")));
            }
        } catch (Exception e) {e.printStackTrace();}
        return list;
    }
    
}
