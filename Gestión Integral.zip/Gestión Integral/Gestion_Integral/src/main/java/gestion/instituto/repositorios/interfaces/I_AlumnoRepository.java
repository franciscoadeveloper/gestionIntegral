package gestion.instituto.repositorios.interfaces;

import gestion.instituto.entities.Alumno;
import gestion.instituto.entities.Curso;
import gestion.instituto.entities.Filial;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public interface I_AlumnoRepository {
    void save(Alumno alumno);
    void remove(Alumno alumno);
    void update(Alumno alumno);
    List<Alumno> getAll();
    default Alumno getById(Integer id){
        if(id==null) return new Alumno();
        return getAll()
                .stream()
                .filter(a->a.getId()==id)
                .findFirst()
                .orElse(new Alumno());
    }
    default List<Alumno> getLikeId(Integer id){
        if(id==null) return new ArrayList<Alumno>();
        return getAll()
                .stream()
                .filter(a->a.getId()==id)
                .collect(Collectors.toList());
    }
    default List<Alumno> getById_filial(Integer id_filial){
        if(id_filial==null) return new ArrayList<Alumno>();
        return getAll()
                .stream()
                .filter(a->a.getId_filial()==id_filial)
                .collect(Collectors.toList());
    }
    default List<Alumno> getById_curso(Integer id_curso){
        if(id_curso==null) return new ArrayList<Alumno>();
        return getAll()
                .stream()
                .filter(a->a.getId_curso()==id_curso)
                .collect(Collectors.toList());
    }
    default List<Alumno> getLikeNombre(String nombre){
        if(nombre==null) return new ArrayList<Alumno>();
        return getAll()
                .stream()
                .filter(a->a.getNombre().toLowerCase().contains(nombre.toLowerCase()))
                .collect(Collectors.toList());
    }
    default List<Alumno> getLikeApellido(String apellido){
        if(apellido==null) return new ArrayList<Alumno>();
        return getAll()
                .stream()
                .filter(a->a.getApellido().toLowerCase().contains(apellido.toLowerCase()))
                .collect(Collectors.toList());
    }
    default List<Alumno> getLikeDni(String dni){
        if(dni==null) return new ArrayList<Alumno>();
        return getAll()
                .stream()
                .filter(a->a.getDni().contains(dni))
                .collect(Collectors.toList());
    }
    default List<Alumno> getLikeDniEmpiezaCon(String dni){
        if(dni==null) return new ArrayList<Alumno>();
        return getAll()
                .stream()
                .filter(a->a.getDni().startsWith(dni))
                .collect(Collectors.toList());
    }
    default List<Alumno> getLikeFechaNac(String fechaNac){
        if(fechaNac==null) return new ArrayList<Alumno>();
        return getAll()
                .stream()
                .filter(a->a.getFechaNac().contains(fechaNac))
                .collect(Collectors.toList());
    }
    default List<Alumno> getByEdad(Integer edad){
        if(edad==null) return new ArrayList<Alumno>();
        return getAll()
                .stream()
                .filter(a->a.getEdad(a.getFechaNac())==edad)
                .collect(Collectors.toList());
    }
    default List<Alumno> getByEdadEntre(Integer edad1,Integer edad2){
        if(edad1==null || edad2==null) return new ArrayList<Alumno>();
        return getAll()
                .stream()
                .filter(a->a.getEdad(a.getFechaNac())>=edad1 && 
                        a.getEdad(a.getFechaNac())<=edad2)
                .collect(Collectors.toList());
    }
    default List<Alumno> getByCurso(Curso curso){
        if(curso==null) return new ArrayList<Alumno>();
        return getAll()
                .stream()
                .filter(a->a.getId_curso()==curso.getId())
                .collect(Collectors.toList());
    }
    default List<Alumno> getByFilial(Filial filial){
        if(filial==null) return new ArrayList<Alumno>();
        return getAll()
                .stream()
                .filter(a->a.getId_filial()==filial.getId())
                .collect(Collectors.toList());
    }


}
