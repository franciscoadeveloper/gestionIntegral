package gestion.instituto.enumerados;
public enum Nivel { nivel1("1"),nivel2("2"),nivel3("3");
    private final String numNivel;
    private Nivel(String numNivel) {this.numNivel = numNivel;}
    public String getNumNivel(){return numNivel;}
    @Override
    public String toString() {
        return numNivel;
    }
    
}
