package gestion.instituto.repositorios.interfaces;

import gestion.instituto.entities.Materia;
import gestion.instituto.entities.ProfeMateria;
import gestion.instituto.entities.Profesor;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public interface I_ProfeMateriaRepository {
    void save(ProfeMateria profeMateria);
    void remove(ProfeMateria profeMateria);
    void update(ProfeMateria profeMateria);
    List<ProfeMateria> getAll();
    default ProfeMateria getById(Integer id){
        if(id==null) return new ProfeMateria();
        return getAll()
                .stream()
                .filter(pm->pm.getId()==id)
                .findFirst()
                .orElse(new ProfeMateria());
    }
    default List<ProfeMateria> getById_profesor(Integer id_profesor){
        if(id_profesor==null) return new ArrayList<ProfeMateria>();
        return getAll()
                .stream()
                .filter(pm->pm.getId_profesor()==id_profesor)
                .collect(Collectors.toList());
    }
    default List<ProfeMateria> getByProfesor(Profesor profesor){
        if(profesor==null) return new ArrayList<ProfeMateria>();
        return getAll()
                .stream()
                .filter(p->p.getId_profesor()==profesor.getId())
                .collect(Collectors.toList());
    }
    default List<ProfeMateria> getById_materia(Integer id_materia){
        if(id_materia==null) return new ArrayList<ProfeMateria>();
        return getAll()
                .stream()
                .filter(pm->pm.getId_materia()==id_materia)
                .collect(Collectors.toList());
    }
    default List<ProfeMateria> getByMateria(Materia materia){
        if(materia==null) return new ArrayList<ProfeMateria>();
        return getAll()
                .stream()
                .filter(p->p.getId_materia()==materia.getId())
                .collect(Collectors.toList());
    }
}
