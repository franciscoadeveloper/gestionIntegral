package gestion.instituto.test;

import gestion.instituto.connector.Connector;
import gestion.instituto.entities.Materia;
import gestion.instituto.enumerados.Nivel;
import gestion.instituto.repositorios.interfaces.I_MateriaRepository;
import gestion.instituto.repositorios.jdbc.MateriaRepository;
import java.sql.Connection;

public class Test_MateriaRepository {
    public static void main(String[] args) {
        try (Connection conn=Connector.getConnection() ){
            
            I_MateriaRepository mr=new MateriaRepository(conn);
            
            System.out.println("\n INICIO DEL Test_MateriaRepository\n");
                        
            
            System.out.println("*********************\n");
            System.out.println("Muestro todas las materias con el método 'getAll':\n");
            mr.getAll().forEach(System.out::println);
            System.out.println("\n*********************\n\n");
                                             
            
            System.out.println("*********************\n");
            System.out.println("Inserto las materias 'Derecho2' e 'Inglés3'"
                    + " con el método 'save':\n");
            Materia materia1=new Materia("Derecho2", Nivel.nivel3);
            mr.save(materia1);
            System.out.println(materia1);
            Materia materia2=new Materia("Inglés3", Nivel.nivel3);
            mr.save(materia2);
            System.out.println(materia2+"\n\n*********************\n\n");            
                                               
            
            System.out.println("*********************\n");
            System.out.println("Busco la materia de id=3 con el método 'getById':\n");
            System.out.println(mr.getById(3)+"\n\n*********************\n\n");
                        
           
            System.out.println("*********************\n");
            System.out.println("Borro la materia de id=6 con el método 'remove':\n");
            mr.remove(mr.getById(6));
            mr.getAll().forEach(System.out::println);
            System.out.println("\n*********************\n\n");
                      
                        
            System.out.println("*********************\n");
            System.out.println("Actualizo el nombre de la materia con id=3 a "
                    + "'Lengua y Literatura' con el método 'update':\n");
            materia2 = mr.getById(3);
            materia2.setNombre("Lengua y Literatura");
            materia2.setNivel(Nivel.nivel2);
            mr.update(materia2);
            mr.getAll().forEach(System.out::println);
            System.out.println("\n*********************\n\n");
                        
            
            System.out.println("*********************\n");
            System.out.println("Busco las materias que en su nombre contengan 'ingl' "
                    + "con el método 'getLikeNombre':\n");
            mr.getLikeNombre("ingl").forEach(System.out::println);
            System.out.println("\n*********************\n\n");
                        
            
            System.out.println("*********************\n");
            System.out.println("Busco las materias de nivel 3 con el método 'getLikeNivel'\n");
            mr.getLikeNivel(Nivel.nivel3).forEach(System.out::println);
            System.out.println("\n*********************\n\n");
                       
            
            System.out.println("FIN DEL Test_MateriaRepository\n\n");
            
        } catch (Exception e) { e.printStackTrace();}
    
    
    }
    

}
