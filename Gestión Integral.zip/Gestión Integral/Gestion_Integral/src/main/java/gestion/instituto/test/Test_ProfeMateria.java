package gestion.instituto.test;

import gestion.instituto.connector.Connector;
import gestion.instituto.entities.ProfeMateria;
import gestion.instituto.repositorios.interfaces.I_ProfeMateriaRepository;
import gestion.instituto.repositorios.jdbc.ProfeMateriaRepository;
import java.sql.Connection;

public class Test_ProfeMateria {
    public static void main(String[] args) {
        try (Connection conn=Connector.getConnection()){
            
            I_ProfeMateriaRepository pmr=new ProfeMateriaRepository(conn);
            
            System.out.println("\n INICIO DEL Test_ProfeMateriaRepository\n");
                        
            
            System.out.println("*********************\n");
            System.out.println("Muestro todas las relaciones de profes_materias"
                    + " con el método 'getAll':\n");
            pmr.getAll().forEach(System.out::println);
            System.out.println("\n*********************\n\n");
                                             
            
            System.out.println("*********************\n");
            System.out.println("Inserto las relaciones 'id_profesor=2 id_materia=2'"
                    + " y 'id_profesor=1 id_materia=3' con el método 'save':\n");
            ProfeMateria profeMateria1=new ProfeMateria(2, 2);
            pmr.save(profeMateria1);
            System.out.println(profeMateria1);
            ProfeMateria profeMateria2=new ProfeMateria(1, 3);
            pmr.save(profeMateria2);
            System.out.println(profeMateria2+"\n\n*********************\n\n");            
                                               
            
            System.out.println("*********************\n");
            System.out.println("Busco la relación de id=3 con el método 'getById':\n");
            System.out.println(pmr.getById(3)+"\n\n*********************\n\n");
                        
           
            System.out.println("*********************\n");
            System.out.println("Borro la relación de id=6 con el método 'remove':\n");
            pmr.remove(pmr.getById(6));
            pmr.getAll().forEach(System.out::println);
            System.out.println("\n*********************\n\n");
                      
                        
            System.out.println("*********************\n");
            System.out.println("Actualizo la relación de id=3 a 'id_profesor=2 "
                    + "id_materia=5' con el método 'update':\n");
            profeMateria2 = pmr.getById(3);
            profeMateria2.setId_profesor(2);
            profeMateria2.setId_materia(5);
            pmr.update(profeMateria2);
            pmr.getAll().forEach(System.out::println);
            System.out.println("\n*********************\n\n");
            
            
            System.out.println("*********************\n");
            System.out.println("Busco las relaciones de id_profesor=1 "
                    + "con el método 'getById_profesor':\n");
            pmr.getById_profesor(1).forEach(System.out::println);
            System.out.println("\n*********************\n\n");
            
            
            System.out.println("*********************\n");
            System.out.println("Busco las relaciones de id_materia=5 "
                    + "con el método 'getById_materia':\n");
            pmr.getById_materia(5).forEach(System.out::println);
            System.out.println("\n*********************\n\n");
            
            
            System.out.println("FIN DEL Test_ProfeMateriaRepository\n\n");
            
        } catch (Exception e) {e.printStackTrace();}
    }
}
