package gestion.instituto.entities;
public class Profesor {
    private int id; 
    private String nombre;
    private String apellido;
    private String dni; 
    private String cuil; 
    private String celular; 
    private String telefonoFijo; 
    private String email; 
    private int id_filial;

    public Profesor() { }

    public Profesor(String nombre, String apellido, String dni, String cuil, 
            String celular, String telefonoFijo, String email, int id_filial) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
        this.cuil = cuil;
        this.celular = celular;
        this.telefonoFijo = telefonoFijo;
        this.email = email;
        this.id_filial = id_filial;
    }

    public Profesor(int id, String nombre, String apellido, String dni, String cuil, 
            String celular, String telefonoFijo, String email, int id_filial) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
        this.cuil = cuil;
        this.celular = celular;
        this.telefonoFijo = telefonoFijo;
        this.email = email;
        this.id_filial = id_filial;
    }

    @Override
    public String toString() {
        return id + " / "+ nombre + ", " + apellido;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getCuil() {
        return cuil;
    }

    public void setCuil(String cuil) {
        this.cuil = cuil;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String getTelefonoFijo() {
        return telefonoFijo;
    }

    public void setTelefonoFijo(String telefonoFijo) {
        this.telefonoFijo = telefonoFijo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getId_filial() {
        return id_filial;
    }

    public void setId_filial(int id_filial) {
        this.id_filial = id_filial;
    }
    
    
    
    
}
