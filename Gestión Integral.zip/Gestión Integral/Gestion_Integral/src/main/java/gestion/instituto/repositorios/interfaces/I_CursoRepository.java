package gestion.instituto.repositorios.interfaces;

import gestion.instituto.entities.Curso;
import gestion.instituto.entities.Filial;
import gestion.instituto.entities.Materia;
import gestion.instituto.entities.Profesor;
import gestion.instituto.enumerados.Dia;
import gestion.instituto.enumerados.Horario;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public interface I_CursoRepository {
    void save(Curso curso);
    void remove(Curso curso);
    void update(Curso curso);
    List<Curso> getAll();
    default Curso getById(Integer id){
        if(id==null) return new Curso();
        return getAll()
                .stream()
                .filter(c->c.getId()==id)
                .findFirst()
                .orElse(new Curso());                
    }
    default List<Curso> getLikeId(Integer id){
        if(id==null) return new ArrayList<Curso>();
        return getAll()
                .stream()
                .filter(c->c.getId()==id)
                .collect(Collectors.toList());
    }
    default List<Curso> getById_profesor(Integer id_profesor){
        if(id_profesor==null) return new ArrayList<Curso>();
        return getAll()
                .stream()
                .filter(c->c.getId_profesor()==id_profesor)
                .collect(Collectors.toList());
    }
    default List<Curso> getByProfesor(Profesor profesor){
        if(profesor==null) return new ArrayList<Curso>();
        return getAll()
                .stream()
                .filter(c->c.getId_profesor()==profesor.getId())
                .collect(Collectors.toList());
    }
    default List<Curso> getById_filial(Integer id_filial){
        if(id_filial==null) return new ArrayList<Curso>();
        return getAll()
                .stream()
                .filter(c->c.getId_filial()==id_filial)
                .collect(Collectors.toList());
    } 
    default List<Curso> getByFilial(Filial filial){
        if(filial==null) return new ArrayList<Curso>();
        return getAll()
                .stream()
                .filter(c->c.getId_filial()==filial.getId())
                .collect(Collectors.toList());
    }
    default List<Curso> getById_materia(Integer id_materia){
        if(id_materia==null) return new ArrayList<Curso>();
        return getAll()
                .stream()
                .filter(c->c.getId_materia()==id_materia)
                .collect(Collectors.toList());
    }
     default List<Curso> getByMateria(Materia materia){
        if(materia==null) return new ArrayList<Curso>();
        return getAll()
                .stream()
                .filter(c->c.getId_materia()==materia.getId())
                .collect(Collectors.toList());
    }   
    default List<Curso> getLikeDia(Dia dia){
        if(dia==null) return new ArrayList<Curso>();
        return getAll()
                .stream()
                .filter(c->c.getDia()==dia)
                .collect(Collectors.toList());
    }
    default List<Curso> getLikeHorario(Horario horario){
        if(horario==null) return new ArrayList<Curso>();
        return getAll()
                .stream()
                .filter(c->c.getHorario()==horario)
                .collect(Collectors.toList());
    }
}
