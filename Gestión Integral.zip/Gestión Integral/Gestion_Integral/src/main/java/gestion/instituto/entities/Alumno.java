package gestion.instituto.entities;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Alumno {
    private int id;
    private String nombre;
    private String apellido;
    private String dni;
    private String celular;
    private String telefonoFijo;
    private String email;
    private String fechaNac;
    private int id_filial;
    private int id_curso;

    public Alumno() {}

    public Alumno(String nombre, String apellido, String dni, String celular,
            String telefonoFijo,String email, String fechaNac, int id_filial, int id_curso) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
        this.celular = celular;
        this.telefonoFijo = telefonoFijo;
        this.email = email;
        this.fechaNac = fechaNac;
        this.id_filial = id_filial;
        this.id_curso = id_curso;
    }

    public Alumno(int id, String nombre, String apellido, String dni, String celular, 
            String telefonoFijo,String email, String fechaNac, int id_filial, int id_curso) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
        this.celular = celular;
        this.telefonoFijo = telefonoFijo;
        this.email = email;
        this.fechaNac = fechaNac;
        this.id_filial = id_filial;
        this.id_curso = id_curso;
    }

    @Override
    public String toString() {
        return "Alumno{" + "id=" + id + ", nombre=" + nombre + ", apellido=" + apellido + ", dni=" 
                + dni + ", celular=" + celular + ", telefonoFijo=" + telefonoFijo + ", email=" + email 
                + ", fechaNac=" + fechaNac + ", id_filial=" + id_filial + ", id_curso=" + id_curso + '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String getTelefonoFijo() {
        return telefonoFijo;
    }

    public void setTelefonoFijo(String telefonoFijo) {
        this.telefonoFijo = telefonoFijo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFechaNac() {
        return fechaNac;
    }
    
    public int getEdad(String fechaNac) {
        Date fecha = null;
        try {
            fecha = new SimpleDateFormat("yyyy-MM-dd").parse(fechaNac);
        } catch (Exception e) {e.printStackTrace();}
        Calendar fechaNacimiento = Calendar.getInstance();
        Calendar fechaActual = Calendar.getInstance();
        fechaNacimiento.setTime(fecha);
        int anio = fechaActual.get(Calendar.YEAR) - fechaNacimiento.get(Calendar.YEAR);
        int mes = fechaActual.get(Calendar.MONTH) - fechaNacimiento.get(Calendar.MONTH);
        int dia = fechaActual.get(Calendar.DATE) - fechaNacimiento.get(Calendar.DATE);
        if (mes < 0 || (mes == 0 && dia < 0)) anio--;
        return anio;
    }

    public void setFechaNac(String fechaNac) {
        this.fechaNac = fechaNac;
    }

    public int getId_filial() {
        return id_filial;
    }

    public void setId_filial(int id_filial) {
        this.id_filial = id_filial;
    }

    public int getId_curso() {
        return id_curso;
    }

    public void setId_curso(int id_curso) {
        this.id_curso = id_curso;
    }
    
    
}
