package gestion.instituto.test;

import gestion.instituto.connector.Connector;
import gestion.instituto.entities.Alumno;
import gestion.instituto.repositorios.interfaces.I_AlumnoRepository;
import gestion.instituto.repositorios.jdbc.AlumnoRepository;
import java.sql.Connection;

public class Test_AlumnoRepository { 
    public static void main(String[] args) {
        try (Connection conn=Connector.getConnection()){
            
            I_AlumnoRepository ar=new AlumnoRepository(conn);
            
            System.out.println("\n INICIO DEL Test_AlumnoRepository\n");
                        
            
            System.out.println("*********************\n");
            System.out.println("Muestro todos los alumnos con el método 'getAll':\n");
            ar.getAll().forEach(System.out::println);
            System.out.println("\n*********************\n\n");
            
            
            System.out.println("*********************\n");
            System.out.println("Inserto los alumnos 'Gabriela Raffo' y 'Luis Pascaja'"
                    + " con el método 'save':\n");
            Alumno alumno1=new Alumno("Gabriela", "Raffo", "19277836", "1546987590",
                    "48796688", "gabrielaraffo@gmail.com", "1978-05-12", 2, 2);
            ar.save(alumno1);
            System.out.println(alumno1);
            Alumno alumno2=new Alumno("Luis", "Pascaja", "32894137", "1546110879", 
                    "66549820", "lucho@gmail.com", "2001-11-01", 1, 1);
            ar.save(alumno2);
            System.out.println(alumno2+"\n\n*********************\n\n"); 
            
            
            System.out.println("*********************\n");
            System.out.println("Busco el alumno de id=7 con el método 'getById':\n");
            System.out.println(ar.getById(7)+"\n\n*********************\n\n");
            
            
            System.out.println("Borro al alumno de id=6 con el método 'remove':\n");
            ar.remove(ar.getById(6));
            ar.getAll().forEach(System.out::println);
            System.out.println("\n*********************\n\n");
            
            
            System.out.println("*********************\n");
            System.out.println("Actualizo el nombre del alumno con id=2 a "
                    + "'Fernando' con el método 'update':\n");
            alumno2 = ar.getById(2);
            alumno2.setNombre("Fernando");
            alumno2.setApellido("Blanco");
            alumno2.setDni("28698474");
            alumno2.setCelular("1156744682");
            alumno2.setTelefonoFijo("48965237");
            alumno2.setEmail("vicenteblanco@gmail.com");
            alumno2.setFechaNac("1995-05-15");
            alumno2.setId_filial(1);
            alumno2.setId_curso(6);
            ar.update(alumno2);
            ar.getAll().forEach(System.out::println);
            System.out.println("\n*********************\n\n");
            
            
            System.out.println("*********************\n");
            System.out.println("Busco los alumnos de id_filial=1 con el método "
                    + "'getById_filial':\n");
            ar.getById_filial(1).forEach(System.out::println);
            System.out.println("\n*********************\n\n");
            
            
            System.out.println("*********************\n");
            System.out.println("Busco los alumnos de id_curso=2 con el método "
                    + "'getById_curso':\n");
            ar.getById_curso(2).forEach(System.out::println);
            System.out.println("\n*********************\n\n");
            
            
            System.out.println("*********************\n");
            System.out.println("Busco los alumnos que en su nombre contengan 'fe' "
                    + "con el método 'getLikeNombre':\n");
            ar.getLikeNombre("fe").forEach(System.out::println);
            System.out.println("\n*********************\n\n");
            
            
            System.out.println("*********************\n");
            System.out.println("Busco los alumnos que en su apellido contengan 'ez' "
                    + "con el método 'getLikeApellido':\n");
            ar.getLikeApellido("ez").forEach(System.out::println);
            System.out.println("\n*********************\n\n");
            
            
            System.out.println("*********************\n");
            System.out.println("Busco los alumnos cuyo DNI comience con '33' "
                    + "con el método 'getLikeDniEmpiezaCon':\n");
            ar.getLikeDniEmpiezaCon("33").forEach(System.out::println);
            System.out.println("\n*********************\n\n");
            
            
            System.out.println("*********************\n");
            System.out.println("Busco los alumnos cuyo DNI contenga '911' "
                    + "con el método 'getLikeDni':\n");
            ar.getLikeDni("911").forEach(System.out::println);
            System.out.println("\n*********************\n\n");
            
            
            System.out.println("*********************\n");
            System.out.println("Busco los alumnos cuyo año de nacimiento sea '1993' "
                    + "con el método 'getLikeFechaNac':\n");
            ar.getLikeFechaNac("1993").forEach(System.out::println);
            System.out.println("\n*********************\n\n");
            
            
            System.out.println("*********************\n");
            System.out.println("Busco los alumnos de edad=39 con el método "
                    + "'getByEdad':\n");
            ar.getByEdad(39).forEach(System.out::println);
            System.out.println("\n*********************\n\n");
            
            
            System.out.println("*********************\n");
            System.out.println("Busco los alumnos cuya edad esté entre 24 y 26 años "
                    + "con el método 'getByEdadEntre':\n");
            ar.getByEdadEntre(24,26).forEach(System.out::println);
            System.out.println("\n*********************\n\n");
            
            
            System.out.println("FIN DEL Test_AlumnoRepository\n\n");
            
            
        } catch (Exception e) {e.printStackTrace();}
        
        
        
    }
}
