package gestion.instituto.entities;
public class ProfeMateria {
    private int id;
    private int id_profesor;
    private int id_materia;

    public ProfeMateria() {}

    public ProfeMateria(int id_profesor, int id_materia) {
        this.id_profesor = id_profesor;
        this.id_materia = id_materia;
    }

    public ProfeMateria(int id, int id_profesor, int id_materia) {
        this.id = id;
        this.id_profesor = id_profesor;
        this.id_materia = id_materia;
    }

    @Override
    public String toString() {
        return "ProfeMateria{" + "id=" + id + ", id_profesor=" + id_profesor + ", id_materia=" + id_materia + '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId_profesor() {
        return id_profesor;
    }

    public void setId_profesor(int id_profesor) {
        this.id_profesor = id_profesor;
    }

    public int getId_materia() {
        return id_materia;
    }

    public void setId_materia(int id_materia) {
        this.id_materia = id_materia;
    }
    
    
}
