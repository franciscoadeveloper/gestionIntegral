package gestion.instituto.test;

import gestion.instituto.connector.Connector;
import gestion.instituto.entities.Filial;
import gestion.instituto.repositorios.interfaces.I_FilialRepository;
import gestion.instituto.repositorios.jdbc.FilialRepository;
import java.sql.Connection;

public class Test_FilialRepository {
    public static void main(String[] args) {
        try (Connection conn=Connector.getConnection()){
            I_FilialRepository fr=new FilialRepository(conn);
            
            System.out.println("\n INICIO DEL Test_FilialRepository\n");
                        
            System.out.println("*********************\n");
            System.out.println("Muestro todas las filiales con el método 'getAll':\n");
            fr.getAll().forEach(System.out::println);
            System.out.println("\n*********************\n\n");
            
                                
            
            System.out.println("*********************\n");
            System.out.println("Inserto las filiales 'Flores' y 'Belgrano' "
                    + "con el método 'save': \n");
            Filial filial1=new Filial("Flores", "Sarmiento 17", "85496213", 4);
            fr.save(filial1);
            System.out.println(filial1);
            Filial filial2=new Filial("Belgrano", "Mosconi 632", "22458861", 3);
            fr.save(filial2);
            System.out.println(filial2+"\n\n*********************\n\n");
                        
            
            
            System.out.println("*********************\n");
            System.out.println("Busco la filial de id=3 con el método 'getById':\n");
            System.out.println(fr.getById(3)+"\n\n*********************\n\n");
            
                                  
            
            System.out.println("*********************\n");
            System.out.println("Elimino la filial de id=7 con el método 'remove':\n");
            fr.remove(fr.getById(7));
            fr.getAll().forEach(System.out::println);
            System.out.println("\n*********************\n\n");
            
            
                       
            System.out.println("*********************\n");
            System.out.println("Actualizo el nombre de la filial id=4 a 'Lanús' "
                    + "con el método 'update':\n");
            filial2=fr.getById(4);
            filial2.setNombre("Lanús");
            filial2.setDireccion("Alvear 44");
            filial2.setTelefono("46983307");
            filial2.setId_sede(2);
            fr.update(filial2);
            System.out.println(filial2+"\n\n*********************\n\n");
            
                        
            
            System.out.println("*********************\n");
            System.out.println("Busco las filiales que tengan nombre='Moreno' "
                    + "con el método 'getLikeNombre':\n");
            fr.getLikeNombre("Moreno").forEach(System.out::println);
            System.out.println("\n*********************\n\n");
            
                        
            
            System.out.println("*********************\n");
            System.out.println("Busco las filiales que tengan el id_sede=3 "
                    + "con el método 'getById_Sede':\n");
            fr.getById_Sede(3).forEach(System.out::println);
            System.out.println("\n*********************\n\n");
            
                        
            
            System.out.println("FIN DEL Test_FilialRepository\n\n");            
            
            
        } catch (Exception e) {e.printStackTrace();}
    }
}
