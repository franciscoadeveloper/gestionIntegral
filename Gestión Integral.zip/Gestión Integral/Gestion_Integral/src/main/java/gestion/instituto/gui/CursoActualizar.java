package gestion.instituto.gui;

import gestion.instituto.connector.Connector;
import gestion.instituto.entities.Curso;
import gestion.instituto.entities.Filial;
import gestion.instituto.entities.Materia;
import gestion.instituto.entities.Profesor;
import gestion.instituto.enumerados.Dia;
import gestion.instituto.enumerados.Horario;
import gestion.instituto.repositorios.interfaces.I_CursoRepository;
import gestion.instituto.repositorios.interfaces.I_FilialRepository;
import gestion.instituto.repositorios.interfaces.I_MateriaRepository;
import gestion.instituto.repositorios.interfaces.I_ProfesorRepository;
import gestion.instituto.repositorios.jdbc.CursoRepository;
import gestion.instituto.repositorios.jdbc.FilialRepository;
import gestion.instituto.repositorios.jdbc.MateriaRepository;
import gestion.instituto.repositorios.jdbc.ProfesorRepository;
import javax.swing.JOptionPane;

public class CursoActualizar extends javax.swing.JInternalFrame {
    I_CursoRepository cr;
    I_ProfesorRepository pr;
    I_FilialRepository fr;
    I_MateriaRepository mr;

    public CursoActualizar() {
        super("Formulario para editar datos del curso", false, true, false, true);        
        pr=new ProfesorRepository(Connector.getConnection());
        fr=new FilialRepository(Connector.getConnection());
        mr=new MateriaRepository(Connector.getConnection());
        cr=new CursoRepository(Connector.getConnection());
        initComponents();
        cargar();
    }
    
    public void cargar(){
        int fila=CursoBuscar.tblCursos.getSelectedRow();
        
        //cargo el JComboBox con la lista de profesores
        cmbProfesor.removeAllItems();
        pr.getAll().forEach(cmbProfesor::addItem);
        
        //selecciono del JComboBox el profesor que tiene el curso desde el JTable
        Profesor profesor=pr.getById((Integer)CursoBuscar.tblCursos.getValueAt(fila, 1));
        cmbProfesor.getModel().setSelectedItem(profesor);
        
        //cargo el JComboBox con la lista de enumerados de Dia
        cmbDia.removeAllItems();
        for (Dia dia : Dia.values()) {cmbDia.addItem(dia);}
        
        //selecciono del JComboBox el día que tiene el curso desde el JTable
        cmbDia.setSelectedItem(CursoBuscar.tblCursos.getValueAt(fila, 2));
        
        //cargo el JComboBox con la lista de enumerados de Horario
        cmbHorario.removeAllItems();
        for (Horario horario : Horario.values()) {cmbHorario.addItem(horario);}
        
        //selecciono del JComboBox el horario que tiene el curso desde el JTable
        cmbHorario.setSelectedItem(CursoBuscar.tblCursos.getValueAt(fila, 3));
        
        //cargo el JComboBox con la lista de filiales
        cmbFilial.removeAllItems();
        fr.getAll().forEach(cmbFilial::addItem);
        
        //selecciono del JComboBox la filial que tiene el curso desde el JTable
        Filial filial=fr.getById((Integer)CursoBuscar.tblCursos.getValueAt(fila, 4));
        cmbFilial.getModel().setSelectedItem(filial);
        
        //cargo el JComboBox con la lista de materias
        cmbMateria.removeAllItems();
        mr.getAll().forEach(cmbMateria::addItem);
        
        //selecciono del JComboBox la materia que tiene el curso desde el JTable
        Materia materia=mr.getById((Integer)CursoBuscar.tblCursos.getValueAt(fila, 5));
        cmbMateria.getModel().setSelectedItem(materia);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        btnCancelar = new javax.swing.JButton();
        cmbProfesor = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        cmbDia = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        cmbHorario = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        cmbFilial = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        cmbMateria = new javax.swing.JComboBox<>();
        btnGuardar = new javax.swing.JButton();
        btnVolver = new javax.swing.JButton();

        jLabel1.setText("Profesor:");

        btnCancelar.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnCancelar.setText("CANCELAR");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        jLabel2.setText("Día:");

        jLabel3.setText("Horario:");

        jLabel4.setText("Filial:");

        jLabel5.setText("Materia:");

        btnGuardar.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnGuardar.setText("GUARDAR");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        btnVolver.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnVolver.setText("VOLVER AL LISTADO DE BÚSQUEDA DE CURSOS");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(80, 80, 80)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addGap(31, 31, 31)
                                .addComponent(cmbHorario, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addComponent(jLabel2)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(cmbDia, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addComponent(jLabel1)
                                    .addGap(26, 26, 26)
                                    .addComponent(cmbProfesor, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel4))
                                .addGap(31, 31, 31)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cmbFilial, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cmbMateria, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(48, 48, 48)
                        .addComponent(btnGuardar)
                        .addGap(39, 39, 39)
                        .addComponent(btnCancelar))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btnVolver)))
                .addContainerGap(14, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbProfesor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cmbDia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbHorario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(11, 11, 11)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cmbFilial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbMateria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(btnVolver, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(26, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        //Evento Cancelar
        this.dispose();
        CursoBuscar cursosBuscar = new CursoBuscar();
        Colegio.desktop.add(cursosBuscar);
        cursosBuscar.setVisible(true);
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        //Evento Actualizar
        int fila=CursoBuscar.tblCursos.getSelectedRow();
        
        //creo la variable que contendrá el valor del ID del alumno para cargarlo en el constructor
        int id=(Integer)CursoBuscar.tblCursos.getValueAt(fila, 0);
        
        //creo el objeto de Profesor desde lo seleccionado en el JComboBox para extraer su ID y cargarlo en el constructor del Alumno
        Profesor profesor=(Profesor)cmbProfesor.getModel().getSelectedItem();
        
        //creo el objeto de Filial desde lo seleccionado en el JComboBox para extraer su ID y cargarlo en el constructor del Alumno
        Filial filial=(Filial)cmbFilial.getModel().getSelectedItem();
        
        //creo el objeto de Materia desde lo seleccionado en el JComboBox para extraer su ID y cargarlo en el constructor del Alumno
        Materia materia=(Materia)cmbMateria.getModel().getSelectedItem();
        
        Curso curso = new Curso(
                id,
                profesor.getId(),
                (Dia) cmbDia.getSelectedItem(),
                (Horario)cmbHorario.getSelectedItem(),
                filial.getId(),materia.getId()
                );
        cr.update(curso);
        JOptionPane.showMessageDialog(this, "El curso ha sido actualizado correctamente! ID de curso: "+curso.getId());
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        //Evento Volver
        this.dispose();
        CursoBuscar cursosBuscar = new CursoBuscar();
        Colegio.desktop.add(cursosBuscar);
        cursosBuscar.setVisible(true);
    }//GEN-LAST:event_btnVolverActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnVolver;
    private javax.swing.JComboBox<Dia> cmbDia;
    private javax.swing.JComboBox<Filial> cmbFilial;
    private javax.swing.JComboBox<Horario> cmbHorario;
    private javax.swing.JComboBox<Materia> cmbMateria;
    private javax.swing.JComboBox<Profesor> cmbProfesor;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    // End of variables declaration//GEN-END:variables
}
