package gestion.instituto.entities;

import gestion.instituto.enumerados.Nivel;

public class Materia {
    private int id;
    private String nombre;
    private Nivel nivel;

    public Materia() {}

    public Materia(String nombre, Nivel nivel) {
        this.nombre = nombre;
        this.nivel = nivel;
    }

    public Materia(int id, String nombre, Nivel nivel) {
        this.id = id;
        this.nombre = nombre;
        this.nivel = nivel;
    }

    @Override
    public String toString() {
        return id + " / " + nombre + " /  Nivel: " + nivel.getNumNivel();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Nivel getNivel() {
        return nivel;
    }

    public void setNivel(Nivel nivel) {
        this.nivel = nivel;
    }
    
    
    
    
}
