package gestion.instituto.repositorios.jdbc;

import gestion.instituto.entities.Sede;
import gestion.instituto.repositorios.interfaces.I_SedeRepository;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class SedeRepository implements I_SedeRepository{
    private Connection conn;

    public SedeRepository(Connection conn) {this.conn = conn;}
    
    @Override
    public void save(Sede sede) {
        if(sede==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
        "insert into sedes (nombre,direccion,telefono) values (?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)){
            ps.setString(1, sede.getNombre());
            ps.setString(2, sede.getDireccion());
            ps.setString(3, sede.getTelefono());
            ps.execute();
            ResultSet rs=ps.getGeneratedKeys();
            if(rs.next()) sede.setId(rs.getInt(1));
        } catch (Exception e) {e.printStackTrace();}
    }

    @Override
    public void remove(Sede sede) {
        if(sede==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
        "delete from sedes where id=?")){
            ps.setInt(1, sede.getId());
            ps.execute();
        } catch (Exception e) {e.printStackTrace();}
    }

    @Override
    public void update(Sede sede) {
        if(sede==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
        "update sedes set nombre=?, direccion=?, telefono=? where id=?")){
            ps.setString(1, sede.getNombre());
            ps.setString(2, sede.getDireccion());
            ps.setString(3, sede.getTelefono());
            ps.setInt(4, sede.getId());
            ps.execute();
        } catch (Exception e) {e.printStackTrace();}
    }

    @Override
    public List<Sede> getAll() {
        List<Sede> list=new ArrayList<Sede>();
        try (ResultSet rs=conn.createStatement().executeQuery(
        "select * from sedes");){
            while(rs.next()){
                list.add(new Sede(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("direccion"),
                        rs.getString("telefono")
                ));
            }
        } catch (Exception e) {e.printStackTrace();}
        return list;
    }
    
}
