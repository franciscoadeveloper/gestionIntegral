package gestion.instituto.repositorios.jdbc;

import gestion.instituto.entities.Filial;
import gestion.instituto.repositorios.interfaces.I_FilialRepository;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import javax.crypto.spec.PSource;

public class FilialRepository implements I_FilialRepository{
    private Connection conn;

    public FilialRepository(Connection conn) {this.conn = conn;}
    
    @Override
    public void save(Filial filial) {
        if(filial==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
        "insert into filiales (nombre,direccion,telefono,id_sede) values "
                + "(?,?,?,?)",PreparedStatement.RETURN_GENERATED_KEYS)){
            ps.setString(1, filial.getNombre());
            ps.setString(2, filial.getDireccion());
            ps.setString(3, filial.getTelefono());
            ps.setInt(4, filial.getId_sede());
            ps.execute();
            ResultSet rs=ps.getGeneratedKeys();
            if(rs.next()) filial.setId(rs.getInt(1));
        } catch (Exception e) {e.printStackTrace();}
    }

    @Override
    public void remove(Filial filial) {
        if(filial==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
        "delete from filiales where id=?")){
            ps.setInt(1, filial.getId());
            ps.execute();            
        } catch (Exception e) {e.printStackTrace();}
    }

    @Override
    public void update(Filial filial) {
        if(filial==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
        "update filiales set nombre=?, direccion=?, telefono=?, id_sede=? "
                + "where id=?")){
            ps.setString(1, filial.getNombre());
            ps.setString(2, filial.getDireccion());
            ps.setString(3, filial.getTelefono());
            ps.setInt(4, filial.getId_sede());
            ps.setInt(5, filial.getId());
            ps.execute();
        } catch (Exception e) {e.printStackTrace();}
    }

    @Override
    public List<Filial> getAll() {
        List<Filial> list=new ArrayList();
        try (ResultSet rs=conn.createStatement().
                executeQuery("select * from filiales")){
            while(rs.next()) {
                list.add(new Filial(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("direccion"),
                        rs.getString("telefono"),
                        rs.getInt("id_sede")));
            }            
        } catch (Exception e) {e.printStackTrace();}
        return list;
    }
    
}
