package gestion.instituto.entities;

import gestion.instituto.enumerados.Dia;
import gestion.instituto.enumerados.Horario;

public class Curso {
    private int id; 
    private int id_profesor; 
    private Dia dia;
    private Horario horario;
    private int id_filial;
    private int id_materia;

    public Curso() {}

    public Curso(int id_profesor, Dia dia, Horario horario, int id_filial, int id_materia) {
        this.id_profesor = id_profesor;
        this.dia=dia;
        this.horario = horario;
        this.id_filial = id_filial;
        this.id_materia = id_materia;
    }

    public Curso(int id, int id_profesor, Dia dia, Horario horario, int id_filial, int id_materia) {
        this.id = id;
        this.id_profesor = id_profesor;
        this.dia = dia;
        this.horario = horario;
        this.id_filial = id_filial;
        this.id_materia = id_materia;
    }

    @Override
    public String toString() {
        return "id:" + id + ", id_profesor:" + id_profesor + ", dia:" + dia.getDiaSemana() + ", horario:"
                + horario.getHorarioCurso() + ", id_filial:" + id_filial + ", id_materia:" + id_materia;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId_profesor() {
        return id_profesor;
    }

    public void setId_profesor(int id_profesor) {
        this.id_profesor = id_profesor;
    }

    public Dia getDia() {
        return dia;
    }

    public void setDia(Dia dia) {
        this.dia = dia;
    }

    public Horario getHorario() {
        return horario;
    }

    public void setHorario(Horario horario) {
        this.horario = horario;
    }

    public int getId_filial() {
        return id_filial;
    }

    public void setId_filial(int id_filial) {
        this.id_filial = id_filial;
    }

    public int getId_materia() {
        return id_materia;
    }

    public void setId_materia(int id_materia) {
        this.id_materia = id_materia;
    }
    
    
    
}
