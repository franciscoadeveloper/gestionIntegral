use baseColegio;

insert into materias values
(null,'Matemática',1),
(null,'Biología',1),
(null,'Lengua',2),
(null,'Inglés',1),
(null,'Contabilidad',3);

insert into sedes values
(null,'Morón','San Martín 319','46277486'),
(null,'Quilmes','Rivadavia 113','44512367'),
(null,'Vicente López','Anatole France 277','23574109'),
(null,'San Miguel','Estrada 1525','26963007');

insert into filiales values
(null,'Moreno','Libertad 152','023578976',1),
(null,'Merlo','Riobamba 422','022078976',1),
(null,'Barrio Norte','Av. Corrientes 12.345','46288945',3),
(null,'Lomas de Zamora','Alvear 44','46983307',2),
(null,'San Martin','Arias 2475','45612388',4);

insert into profesores values
(null,'Matias','Caballero','12456987','20124569870','11698302467','46598203','matiascaballero@yahoo.com.ar',1),
(null,'Laura','Fernández','22000856','22220008564','1193024568','45632229','laurafernandez@gmail.com',2),
(null,'Guillermo','Canteros','28654130','20286541300','1178215487','49821357','guillermocanteros@yahoo.com.ar',3),
(null,'Emmanuel','González','20493051','20204930510','1193002468','48779856','emmanuelgonzalez@gmail.com',4),
(null,'Lidia','Crespo','19992658','22199926584','1136590041','46523654','lidiacrespo@hotmail.com',5);

insert into cursos values
(null,1,'lunes y miercoles','18 a 19,30hs.',1,2),
(null,2,'sabados','9 a 12hs.',2,4),
(null,3,'martes y jueves','19,30 a 21hs.',3,2),
(null,4,'lunes y miercoles','18 a 19,30hs.',4,3),
(null,4,'lunes y miercoles','19,30 a 21hs.',4,3),
(null,1,'martes y jueves','18 a 19,30hs.',1,5);

insert into alumnos values
(null,'Graciela','Alonso','23659874','1156897485','44835689','gracielalonso@gmail.com','1990-01-20',1,1),
(null,'Vicente','Blanco','28698474','1156744682','48965237','vicenteblanco@gmail.com','1995-05-15',1,6),
(null,'Monica','Cataldi','28954112','1145983267','45812305','monicacataldi@hotmail.com','1980-07-28',2,2),
(null,'Marcelo','Perez','33691164','1169853649','46298645','marceloperez@yahoo.com.ar','1993-01-05',3,3),
(null,'Felipe','Paez','33911664','1169853649','46298645','marceloperez@yahoo.com.ar','1993-01-05',2,1),
(null,'Gonzalo','Manguez','91164911','1169853649','46298645','marceloperez@yahoo.com.ar','1993-01-05',2,1),
(null,'Teresa','Valdi','27610911','1169853649','46298645','marceloperez@yahoo.com.ar','1993-01-05',4,4),
(null,'Fernando','Fonseca','28954112','1145983267','45812305','monicacataldi@hotmail.com','1980-07-28',2,2),
(null,'Omar','Marquez','30303898','1142361552','46298700','omarmarquez@yahoo.com.ar','1999-12-19',5,null);

insert into profes_materias values
(null,1,1),
(null,1,5),
(null,2,4),
(null,3,2),
(null,4,3);

select * from cursos;







