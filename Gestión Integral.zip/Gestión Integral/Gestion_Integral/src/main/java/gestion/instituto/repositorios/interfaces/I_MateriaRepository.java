package gestion.instituto.repositorios.interfaces;
import gestion.instituto.entities.Materia;
import gestion.instituto.enumerados.Nivel;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
public interface I_MateriaRepository {
    void save(Materia materia);
    void remove(Materia materia);
    void update(Materia materia);
    List<Materia>getAll();
    default Materia getById(Integer id){
        if(id==null) return new Materia();
        return getAll()
                .stream()
                .filter(m->m.getId()==id)
                .findFirst()
                .orElse(new Materia());
    }
    default List<Materia> getLikeId(Integer id){
        if(id==null) return new ArrayList<Materia>();
        return getAll()
                .stream()
                .filter(m->m.getId()==id)
                .collect(Collectors.toList());
    }
    default List<Materia> getLikeNombre(String nombre){
        if(nombre==null) return new ArrayList<Materia>();
        return getAll()
                .stream()
                .filter(m->m.getNombre().toLowerCase().contains(nombre.toLowerCase()))
                .collect(Collectors.toList());
    }
    default List<Materia> getLikeNivel(Nivel nivel){
        if(nivel==null) return new ArrayList<Materia>();
        return getAll()
                .stream()
                .filter(m->m.getNivel()==nivel)
                .collect(Collectors.toList());
    }
}
