package gestion.instituto.test;

import gestion.instituto.connector.Connector;
import java.sql.Connection;


public class Test_Connection {
    public static void main(String[] args) {
        try (Connection conn = Connector.getConnection()){
            conn.createStatement().execute(
                    "insert into sedes (nombre,direccion,telefono) "
                    + "values ('Liniers','R. Falcón 727','48796532')"
            );
        } catch (Exception e) { e.printStackTrace(); }
    }
}
