package gestion.instituto.gui;

import gestion.instituto.connector.Connector;
import gestion.instituto.entities.Curso;
import gestion.instituto.entities.Filial;
import gestion.instituto.entities.Materia;
import gestion.instituto.entities.Profesor;
import gestion.instituto.enumerados.Dia;
import gestion.instituto.enumerados.Horario;
import gestion.instituto.repositorios.interfaces.I_AlumnoRepository;
import gestion.instituto.repositorios.interfaces.I_CursoRepository;
import gestion.instituto.repositorios.interfaces.I_FilialRepository;
import gestion.instituto.repositorios.interfaces.I_MateriaRepository;
import gestion.instituto.repositorios.interfaces.I_ProfesorRepository;
import gestion.instituto.repositorios.jdbc.AlumnoRepository;
import gestion.instituto.repositorios.jdbc.CursoRepository;
import gestion.instituto.repositorios.jdbc.FilialRepository;
import gestion.instituto.repositorios.jdbc.MateriaRepository;
import gestion.instituto.repositorios.jdbc.ProfesorRepository;
import gestion.instituto.util.Table;
import javax.swing.JOptionPane;

public class CursoBuscar extends javax.swing.JInternalFrame {
    I_CursoRepository cr;
    I_ProfesorRepository pr;
    I_FilialRepository fr;
    I_MateriaRepository mr;
    I_AlumnoRepository ar;

    public CursoBuscar() {
        super("Formulario para buscar cursos", false, true, false, true);        
        pr=new ProfesorRepository(Connector.getConnection());
        fr=new FilialRepository(Connector.getConnection());
        mr=new MateriaRepository(Connector.getConnection());
        cr=new CursoRepository(Connector.getConnection());
        ar=new AlumnoRepository(Connector.getConnection());
        initComponents();
        cargar();
        btnActualizar.setVisible(false);
        btnEliminar.setVisible(false);
    }
    
    public void cargar(){
        //cargo el JcomboBox con la lista de Profesores
        cmbProfesor.removeAllItems();
        pr.getAll().forEach(cmbProfesor::addItem);
        
        //cargo el JComboBox con los enumerados de Dia
        cmbDia.removeAllItems();
        for (Dia dia : Dia.values()) {cmbDia.addItem(dia);}
        
        //cargo el JComboBox con los enumerados de Horario
        cmbHorario.removeAllItems();
        for (Horario horario : Horario.values()) {cmbHorario.addItem(horario);}
        
        //cargo el JComboBox con la lista de Filiales
        cmbFilial.removeAllItems();
        fr.getAll().forEach(cmbFilial::addItem);
        
        //cargo el JComboBox con la lista de Materias
        cmbMateria.removeAllItems();
        mr.getAll().forEach(cmbMateria::addItem);
        
        //cargo el JTable con todos los objetos de la clase Curso
        new Table<Curso>().cargar(tblCursos, cr.getAll());
        
        btnEliminar.setVisible(false);
        btnActualizar.setVisible(false);
    }
    
    public void limpiar(){
        cmbProfesor.setSelectedIndex(0);
        cmbDia.setSelectedIndex(0);
        cmbHorario.setSelectedIndex(0);
        cmbFilial.setSelectedIndex(0);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel8 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        txtId = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        cmbProfesor = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        cmbDia = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        cmbHorario = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        cmbFilial = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        cmbMateria = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblCursos = new javax.swing.JTable();
        btnActualizar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();

        jLabel8.setBackground(new java.awt.Color(102, 102, 102));
        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 30)); // NOI18N
        jLabel8.setText("BUSCAR CURSO POR...");

        jLabel1.setText("ID:");

        txtId.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdActionPerformed(evt);
            }
        });
        txtId.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtIdKeyReleased(evt);
            }
        });

        jLabel2.setText("Profesor:");

        cmbProfesor.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cmbProfesorMouseClicked(evt);
            }
        });
        cmbProfesor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbProfesorActionPerformed(evt);
            }
        });

        jLabel3.setText("Día:");

        cmbDia.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cmbDiaMouseClicked(evt);
            }
        });
        cmbDia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbDiaActionPerformed(evt);
            }
        });

        jLabel4.setText("Horario:");

        cmbHorario.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cmbHorarioMouseClicked(evt);
            }
        });
        cmbHorario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbHorarioActionPerformed(evt);
            }
        });

        jLabel5.setText("Filial:");

        cmbFilial.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cmbFilialMouseClicked(evt);
            }
        });
        cmbFilial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbFilialActionPerformed(evt);
            }
        });

        jLabel6.setText("Materia:");

        cmbMateria.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cmbMateriaMouseClicked(evt);
            }
        });
        cmbMateria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbMateriaActionPerformed(evt);
            }
        });

        tblCursos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblCursos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblCursosMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblCursos);

        btnActualizar.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnActualizar.setText("ACTUALIZAR");
        btnActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarActionPerformed(evt);
            }
        });

        btnEliminar.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnEliminar.setText("ELIMINAR");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnLimpiar.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnLimpiar.setText("LIMPIAR");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnLimpiar, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(btnActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(117, 117, 117)
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 387, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel1)
                        .addGap(4, 4, 4)
                        .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(jLabel2)
                        .addGap(6, 6, 6)
                        .addComponent(cmbProfesor, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3)
                        .addGap(6, 6, 6)
                        .addComponent(cmbDia, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(4, 4, 4)
                        .addComponent(jLabel4)
                        .addGap(4, 4, 4)
                        .addComponent(cmbHorario, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(87, 87, 87)
                        .addComponent(jLabel5)
                        .addGap(4, 4, 4)
                        .addComponent(cmbFilial, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(48, 48, 48)
                        .addComponent(jLabel6)
                        .addGap(4, 4, 4)
                        .addComponent(cmbMateria, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 655, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 3, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addComponent(jLabel8)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addComponent(jLabel2))
                    .addComponent(cmbProfesor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addComponent(jLabel3))
                    .addComponent(cmbDia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addComponent(jLabel4))
                    .addComponent(cmbHorario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cmbFilial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbMateria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6))))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 265, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnLimpiar, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(39, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cmbHorarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbHorarioActionPerformed
        new Table<Curso>().cargar(tblCursos, cr.getLikeHorario((Horario)cmbHorario.getSelectedItem()));
    }//GEN-LAST:event_cmbHorarioActionPerformed

    private void txtIdKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtIdKeyReleased
        cmbProfesor.setSelectedIndex(0);
        cmbDia.setSelectedIndex(0);
        cmbHorario.setSelectedIndex(0);
        cmbFilial.setSelectedIndex(0);
        btnEliminar.setVisible(false);
        btnActualizar.setVisible(false);
        if(txtId.getText().isEmpty()) {
            new Table<Curso>().cargar(tblCursos, cr.getAll());
        }else{
        new Table<Curso>().cargar(tblCursos, cr.getLikeId(Integer.parseInt(txtId.getText())));}  
    }//GEN-LAST:event_txtIdKeyReleased

    private void cmbProfesorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbProfesorActionPerformed
        new Table<Curso>().cargar(tblCursos, cr.getByProfesor((Profesor)cmbProfesor.getSelectedItem()));
    }//GEN-LAST:event_cmbProfesorActionPerformed

    private void txtIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdActionPerformed

    private void cmbDiaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbDiaActionPerformed
        new Table<Curso>().cargar(tblCursos, cr.getLikeDia((Dia)cmbDia.getSelectedItem()));
    }//GEN-LAST:event_cmbDiaActionPerformed

    private void cmbProfesorMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cmbProfesorMouseClicked
        txtId.setText("");
        cmbDia.setSelectedIndex(0);
        cmbHorario.setSelectedIndex(0);
        cmbFilial.setSelectedIndex(0);
        cmbMateria.setSelectedIndex(0);
        btnEliminar.setVisible(false);
        btnActualizar.setVisible(false);
    }//GEN-LAST:event_cmbProfesorMouseClicked

    private void cmbDiaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cmbDiaMouseClicked
        txtId.setText("");
        cmbProfesor.setSelectedIndex(0);
        cmbHorario.setSelectedIndex(0);
        cmbFilial.setSelectedIndex(0);
        cmbMateria.setSelectedIndex(0);
        btnEliminar.setVisible(false);
        btnActualizar.setVisible(false);
    }//GEN-LAST:event_cmbDiaMouseClicked

    private void cmbHorarioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cmbHorarioMouseClicked
        txtId.setText("");
        cmbProfesor.setSelectedIndex(0);
        cmbDia.setSelectedIndex(0);
        cmbFilial.setSelectedIndex(0);
        cmbMateria.setSelectedIndex(0);
        btnEliminar.setVisible(false);
        btnActualizar.setVisible(false);
    }//GEN-LAST:event_cmbHorarioMouseClicked

    private void cmbFilialMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cmbFilialMouseClicked
        txtId.setText("");
        cmbProfesor.setSelectedIndex(0);
        cmbDia.setSelectedIndex(0);
        cmbHorario.setSelectedIndex(0);
        cmbMateria.setSelectedIndex(0);
        btnEliminar.setVisible(false);
        btnActualizar.setVisible(false);
    }//GEN-LAST:event_cmbFilialMouseClicked

    private void cmbFilialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbFilialActionPerformed
        new Table<Curso>().cargar(tblCursos, cr.getByFilial((Filial)cmbFilial.getSelectedItem()));
    }//GEN-LAST:event_cmbFilialActionPerformed

    private void cmbMateriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbMateriaActionPerformed
        new Table<Curso>().cargar(tblCursos, cr.getByMateria((Materia)cmbMateria.getSelectedItem()));
    }//GEN-LAST:event_cmbMateriaActionPerformed

    private void tblCursosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblCursosMouseClicked
        btnEliminar.setVisible(true);
        btnActualizar.setVisible(true);
    }//GEN-LAST:event_tblCursosMouseClicked

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        //Evento Eliminar
        int fila=tblCursos.getSelectedRow();
        if(fila==-1) return; 
        
        //creo una variable con la propiedad de salto de línea para utilizar en el JOptionPane
        String line=System.getProperty("line.separator");
                       
        Curso curso=cr.getById((int)tblCursos.getValueAt(fila, 0));
        if(!ar.getByCurso(curso).isEmpty()){
            JOptionPane.showMessageDialog(this, "El curso no puede ser dado de baja porque tiene alumnos inscriptos.",
                    "EL CURSO CONTIENE ALUMNOS",JOptionPane.ERROR_MESSAGE);
        return;}        
        if(JOptionPane.showConfirmDialog(this, "ATENCIÓN. ESTÁ POR DAR DE BAJA UN CURSO."+line+
                "Realmente desea dar de baja al curso de ID "+curso.getId()+"?")!=0) return;
        cr.remove(curso);
        JOptionPane.showMessageDialog(this, "El curso ha sido dado de baja correctamente");
        limpiar();
        cargar();
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void cmbMateriaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cmbMateriaMouseClicked
        txtId.setText("");
        cmbProfesor.setSelectedIndex(0);
        cmbDia.setSelectedIndex(0);
        cmbHorario.setSelectedIndex(0);
        cmbFilial.setSelectedIndex(0);
        btnEliminar.setVisible(false);
        btnActualizar.setVisible(false);
    }//GEN-LAST:event_cmbMateriaMouseClicked

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed
        //Evento Llamada al formulario de actualización de datos
        CursoActualizar cursosActualizar = new CursoActualizar();
        Colegio.desktop.add(cursosActualizar);
        cursosActualizar.toFront();
        cursosActualizar.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnActualizarActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        limpiar();
        cargar();
    }//GEN-LAST:event_btnLimpiarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JComboBox<Dia> cmbDia;
    private javax.swing.JComboBox<Filial> cmbFilial;
    private javax.swing.JComboBox<Horario> cmbHorario;
    private javax.swing.JComboBox<Materia> cmbMateria;
    private javax.swing.JComboBox<Profesor> cmbProfesor;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    public static javax.swing.JTable tblCursos;
    private javax.swing.JTextField txtId;
    // End of variables declaration//GEN-END:variables
}
