package gestion.instituto.gui;

import gestion.instituto.connector.Connector;
import gestion.instituto.entities.Filial;
import gestion.instituto.entities.Sede;
import gestion.instituto.repositorios.interfaces.I_AlumnoRepository;
import gestion.instituto.repositorios.interfaces.I_CursoRepository;
import gestion.instituto.repositorios.interfaces.I_FilialRepository;
import gestion.instituto.repositorios.interfaces.I_ProfesorRepository;
import gestion.instituto.repositorios.interfaces.I_SedeRepository;
import gestion.instituto.repositorios.jdbc.AlumnoRepository;
import gestion.instituto.repositorios.jdbc.CursoRepository;
import gestion.instituto.repositorios.jdbc.FilialRepository;
import gestion.instituto.repositorios.jdbc.ProfesorRepository;
import gestion.instituto.repositorios.jdbc.SedeRepository;
import gestion.instituto.util.Table;
import javax.swing.JOptionPane;

public class FilialBuscar extends javax.swing.JInternalFrame {
    I_FilialRepository fr;
    I_SedeRepository sr;
    I_AlumnoRepository ar;
    I_ProfesorRepository pr;
    I_CursoRepository cr;

    public FilialBuscar() {
        super("Formulario para buscar filiales", false, true, false, true);        
        fr=new FilialRepository(Connector.getConnection());
        sr=new SedeRepository(Connector.getConnection());
        ar=new AlumnoRepository(Connector.getConnection());
        pr=new ProfesorRepository(Connector.getConnection());
        cr=new CursoRepository(Connector.getConnection());
        initComponents();
        cargar();
        btnEliminar.setVisible(false);
        btnActualizar.setVisible(false);
    }
    
    public void cargar(){
        //cargo el JComboBox con la lista de sedes
        cmbSede.removeAllItems();
        sr.getAll().forEach(cmbSede::addItem);
        
        //cargo el JTable con todas las filiales
        new Table<Filial>().cargar(tblFilial, fr.getAll());
        
        btnEliminar.setVisible(false);
        btnActualizar.setVisible(false);
    }
    
    public void limpiar(){
        txtId.setText("");
        txtNombre.setText("");
        cmbSede.setSelectedIndex(0);
        txtId.requestFocus();
    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtId = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        cmbSede = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblFilial = new javax.swing.JTable();
        btnActualizar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnLimpiar = new javax.swing.JButton();

        jLabel3.setText("jLabel3");

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setText("Buscar filial por ...");

        jLabel2.setText("ID:");

        txtId.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtIdKeyReleased(evt);
            }
        });

        jLabel4.setText("Nombre:");

        txtNombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtNombreKeyReleased(evt);
            }
        });

        jLabel5.setText("Sede:");

        cmbSede.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cmbSedeMouseClicked(evt);
            }
        });
        cmbSede.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbSedeActionPerformed(evt);
            }
        });

        tblFilial.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblFilial.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblFilialMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblFilial);

        btnActualizar.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnActualizar.setText("ACTUALIZAR");
        btnActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarActionPerformed(evt);
            }
        });

        btnEliminar.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnEliminar.setText("ELIMINAR");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnLimpiar.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnLimpiar.setText("LIMPIAR");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cmbSede, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnLimpiar, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 13, Short.MAX_VALUE)
                        .addComponent(btnActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(15, 15, 15)
                        .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(112, 112, 112))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbSede, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnLimpiar, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(56, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtIdKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtIdKeyReleased
        txtNombre.setText("");
        cmbSede.setSelectedIndex(0);
        btnEliminar.setVisible(false);
        btnActualizar.setVisible(false);
        if(txtId.getText().isEmpty()) {
            new Table<Filial>().cargar(tblFilial, fr.getAll());
        }else{
        new Table<Filial>().cargar(tblFilial, fr.getLikeId(Integer.parseInt(txtId.getText())));}   
    }//GEN-LAST:event_txtIdKeyReleased

    private void txtNombreKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNombreKeyReleased
        txtId.setText("");
        cmbSede.setSelectedIndex(0);
        btnEliminar.setVisible(false);
        btnActualizar.setVisible(false);
        new Table<Filial>().cargar(tblFilial, fr.getLikeNombre(txtNombre.getText()));
    }//GEN-LAST:event_txtNombreKeyReleased

    private void cmbSedeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbSedeActionPerformed
        new Table<Filial>().cargar(tblFilial, fr.getBySede((Sede)cmbSede.getSelectedItem()));   
    }//GEN-LAST:event_cmbSedeActionPerformed

    private void cmbSedeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cmbSedeMouseClicked
        txtId.setText("");
        txtNombre.setText("");
        btnEliminar.setVisible(false);
        btnActualizar.setVisible(false);
    }//GEN-LAST:event_cmbSedeMouseClicked

    private void tblFilialMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblFilialMouseClicked
        btnEliminar.setVisible(true);
        btnActualizar.setVisible(true);
    }//GEN-LAST:event_tblFilialMouseClicked

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        //Evento Eliminar
        int fila=tblFilial.getSelectedRow();
        if(fila==-1) return;
        
        //creo una variable con la propiedad de salto de línea para utilizar en el JOptionPane
        String line=System.getProperty("line.separator");
        
        Filial filial=fr.getById((Integer)tblFilial.getValueAt(fila, 0));
        if(!ar.getByFilial(filial).isEmpty()){
            JOptionPane.showMessageDialog(this, "La filial no puede ser dada de baja porque tiene alumnos asociados!",
                    "LA FILIAL TIENE ALUMNOS INSCRIPTOS",JOptionPane.ERROR_MESSAGE);
            return;
        }
        if(!pr.getById_filial(filial.getId()).isEmpty()){
            JOptionPane.showMessageDialog(this, "La filial no puede ser dada de baja porque tiene profesores asociados!",
                    "LA FILIAL CONTIENE PROFESORES",JOptionPane.ERROR_MESSAGE);
            return;
        }
        if(!cr.getById_filial(filial.getId()).isEmpty()){
            JOptionPane.showMessageDialog(this, "La filial no puede ser dada de baja porque tiene cursos asociados",
                    "LA FILIAL TIENE CURSOS ACTIVOS",JOptionPane.ERROR_MESSAGE);
            return;
        }
        if(JOptionPane.showConfirmDialog(this, "ATENCIÓN. ESTÁ POR DAR DE BAJA UNA FILIAL."+line+
                "Realmente desea dar de baja la filial "+filial.getNombre()+" de ID "+filial.getId()+" ?")!=0) return;
        fr.remove(filial);
        JOptionPane.showMessageDialog(this, "La filial ha sido eliminada");
        limpiar();
        cargar();
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed
        //Evento Llamada al formulario de edición de datos
        FilialActualizar filialActualizar = new FilialActualizar();
        Colegio.desktop.add(filialActualizar);
        filialActualizar.toFront();
        filialActualizar.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnActualizarActionPerformed

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        limpiar();
        cargar();
    }//GEN-LAST:event_btnLimpiarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JComboBox<Sede> cmbSede;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    public static javax.swing.JTable tblFilial;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtNombre;
    // End of variables declaration//GEN-END:variables
}
