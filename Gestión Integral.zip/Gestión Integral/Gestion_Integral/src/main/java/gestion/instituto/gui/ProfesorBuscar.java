package gestion.instituto.gui;

import gestion.instituto.connector.Connector;
import gestion.instituto.entities.Filial;
import gestion.instituto.entities.Profesor;
import gestion.instituto.repositorios.interfaces.I_CursoRepository;
import gestion.instituto.repositorios.interfaces.I_FilialRepository;
import gestion.instituto.repositorios.interfaces.I_ProfeMateriaRepository;
import gestion.instituto.repositorios.interfaces.I_ProfesorRepository;
import gestion.instituto.repositorios.jdbc.CursoRepository;
import gestion.instituto.repositorios.jdbc.FilialRepository;
import gestion.instituto.repositorios.jdbc.ProfeMateriaRepository;
import gestion.instituto.repositorios.jdbc.ProfesorRepository;
import gestion.instituto.util.Table;
import javax.swing.JOptionPane;

public class ProfesorBuscar extends javax.swing.JInternalFrame {
    I_ProfesorRepository pr;
    I_FilialRepository fr;
    I_CursoRepository cr;
    I_ProfeMateriaRepository pm;

    public ProfesorBuscar() {
        super("Formulario de búsqueda de profesores", false, true, false, true);
        pr=new ProfesorRepository(Connector.getConnection());
        fr=new FilialRepository(Connector.getConnection());
        cr=new CursoRepository(Connector.getConnection());
        pm=new ProfeMateriaRepository(Connector.getConnection());
        initComponents();
        cargar();
        btnActualizar.setVisible(false);
        btnEliminar.setVisible(false);
    }
    
    public void cargar(){
        //cargo el JComboBox con la lista de filiales
        cmbFilial.removeAllItems();
        fr.getAll().forEach(cmbFilial::addItem);
        
        //cargo el JTable con todos los objetos de Profesor
        new Table<Profesor>().cargar(tblProfesores, pr.getAll());
        
        btnEliminar.setVisible(false);
        btnActualizar.setVisible(false);
    }
    
    public void limpiar(){
        txtId.setText("");
        txtNombre.setText("");
        txtApellido.setText("");
        txtDni.setText("");
        cmbFilial.setSelectedIndex(0);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        cmbFilial = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        txtApellido = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        btnActualizar = new javax.swing.JButton();
        txtDni = new javax.swing.JTextField();
        btnEliminar = new javax.swing.JButton();
        txtId = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblProfesores = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        btnLimpiar = new javax.swing.JButton();

        setPreferredSize(new java.awt.Dimension(780, 727));

        cmbFilial.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cmbFilialMouseClicked(evt);
            }
        });
        cmbFilial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbFilialActionPerformed(evt);
            }
        });

        jLabel2.setText("Apellido:");

        txtApellido.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtApellidoKeyReleased(evt);
            }
        });

        jLabel8.setBackground(new java.awt.Color(102, 102, 102));
        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 30)); // NOI18N
        jLabel8.setText("BUSCAR PROFESOR POR...");

        jLabel3.setText("DNI:");

        btnActualizar.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnActualizar.setText("ACTUALIZAR");
        btnActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualizarActionPerformed(evt);
            }
        });

        txtDni.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtDniKeyReleased(evt);
            }
        });

        btnEliminar.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnEliminar.setText("ELIMINAR");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        txtId.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtIdKeyReleased(evt);
            }
        });

        tblProfesores.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblProfesores.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblProfesoresMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblProfesores);

        jLabel6.setText("Filial:");

        jLabel1.setText("Nombre:");

        jLabel7.setText("ID:");

        txtNombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtNombreKeyReleased(evt);
            }
        });

        btnLimpiar.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnLimpiar.setText("LIMPIAR");
        btnLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimpiarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(49, 49, 49)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnLimpiar, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(cmbFilial, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(56, 56, 56)
                                .addComponent(btnActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(38, 38, 38)
                                .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(163, 163, 163)
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 417, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jLabel7)
                        .addGap(51, 51, 51)
                        .addComponent(jLabel1)
                        .addGap(204, 204, 204)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtApellido, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtDni, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(59, 59, 59))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(44, 44, 44)
                    .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(56, 56, 56)
                    .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGroup(layout.createSequentialGroup()
                    .addGap(1, 1, 1)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 774, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel8)
                .addGap(19, 19, 19)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtApellido, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtDni, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cmbFilial, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 472, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnLimpiar, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnActualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(77, 77, 77)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(txtId, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(66, 66, 66)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 415, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(117, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cmbFilialMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cmbFilialMouseClicked
        txtNombre.setText("");
        txtApellido.setText("");
        txtDni.setText("");
        txtId.setText("");
        btnEliminar.setVisible(false);
        btnActualizar.setVisible(false);
    }//GEN-LAST:event_cmbFilialMouseClicked

    private void cmbFilialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbFilialActionPerformed
        new Table<Profesor>().cargar(tblProfesores, pr.getByFilial((Filial) cmbFilial.getSelectedItem()));
    }//GEN-LAST:event_cmbFilialActionPerformed

    private void txtApellidoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtApellidoKeyReleased
        txtNombre.setText("");
        txtDni.setText("");
        txtId.setText("");
        cmbFilial.setSelectedIndex(0);
        btnEliminar.setVisible(false);
        btnActualizar.setVisible(false);
        new Table<Profesor>().cargar(tblProfesores, pr.getLikeApellido(txtApellido.getText()));
    }//GEN-LAST:event_txtApellidoKeyReleased

    private void btnActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualizarActionPerformed
        //Evento Llamada al formulario de edición
        ProfesorActualizar profesorActualizar=new ProfesorActualizar();
        Colegio.desktop.add(profesorActualizar);
        profesorActualizar.toFront();
        profesorActualizar.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_btnActualizarActionPerformed

    private void txtDniKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDniKeyReleased
        txtNombre.setText("");
        txtApellido.setText("");
        txtId.setText("");
        cmbFilial.setSelectedIndex(0);
        btnEliminar.setVisible(false);
        btnActualizar.setVisible(false);
        new Table<Profesor>().cargar(tblProfesores, pr.getLikeDni(txtDni.getText()));
    }//GEN-LAST:event_txtDniKeyReleased

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        //Evento Eliminar
        int fila=tblProfesores.getSelectedRow();
        if(fila==-1) return;

        //creo una variable con la propiedad de salto de línea para utilizar en el JOptionPane
        String line=System.getProperty("line.separator");

        Profesor profesor = pr.getById((Integer) tblProfesores.getValueAt(fila, 0));
        
        if(!cr.getById_profesor(profesor.getId()).isEmpty()){
            JOptionPane.showMessageDialog(this, "No se puede dar de baja al profesor porque pertenece a un curso",
                    "PROFESOR ASIGNADO A CURSO/S",JOptionPane.ERROR_MESSAGE);
            return;
        }
        if(!pm.getById_profesor(profesor.getId()).isEmpty()){
            JOptionPane.showMessageDialog(this, "El profesor no puede ser dado de baja porque tiene una materia asociada",
                    "PROFESOR ASIGNADO A MATERIA/S",JOptionPane.ERROR_MESSAGE);
            return;
        }
        if(JOptionPane.showConfirmDialog( this, "ATENCIÓN!! ESTÁ POR DAR DE BAJA A UN PROFESOR"+line+
            "Realmente desea dar de baja al profesor: "+profesor.getNombre()+" "+profesor.getApellido()+" ?")!=0) return;
        pr.remove(profesor);
        JOptionPane.showMessageDialog(this, "EL PROFESOR HA SIDO DADO DE BAJA CORRECTAMENTE");
        limpiar();
        cargar();
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void txtIdKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtIdKeyReleased
        txtNombre.setText("");
        txtApellido.setText("");
        txtDni.setText("");
        cmbFilial.setSelectedIndex(0);
        btnEliminar.setVisible(false);
        btnActualizar.setVisible(false);
        if(txtId.getText().isEmpty()) {
            new Table<Profesor>().cargar(tblProfesores, pr.getAll());
        }else{
            new Table<Profesor>().cargar(tblProfesores, pr.getLikeId(Integer.parseInt(txtId.getText())));}
    }//GEN-LAST:event_txtIdKeyReleased

    private void tblProfesoresMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblProfesoresMouseClicked
        btnEliminar.setVisible(true);
        btnActualizar.setVisible(true);
    }//GEN-LAST:event_tblProfesoresMouseClicked

    private void txtNombreKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNombreKeyReleased
        txtApellido.setText("");
        txtDni.setText("");
        txtId.setText("");
        cmbFilial.setSelectedIndex(0);
        btnEliminar.setVisible(false);
        btnActualizar.setVisible(false);
        new Table<Profesor>().cargar(tblProfesores, pr.getLikeNombre(txtNombre.getText()));
    }//GEN-LAST:event_txtNombreKeyReleased

    private void btnLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimpiarActionPerformed
        cargar();
    }//GEN-LAST:event_btnLimpiarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnActualizar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnLimpiar;
    private javax.swing.JComboBox<Filial> cmbFilial;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    public static javax.swing.JTable tblProfesores;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JTextField txtDni;
    private javax.swing.JTextField txtId;
    private javax.swing.JTextField txtNombre;
    // End of variables declaration//GEN-END:variables
}
