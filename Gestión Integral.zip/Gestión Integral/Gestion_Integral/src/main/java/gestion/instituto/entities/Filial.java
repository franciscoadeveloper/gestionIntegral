package gestion.instituto.entities;
public class Filial {
    private int id;
    private String nombre;
    private String direccion;
    private String telefono;
    private int id_sede;

    public Filial() {
    }

    public Filial(String nombre, String direccion, String telefono, int id_sede) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.telefono = telefono;
        this.id_sede = id_sede;
    }

    public Filial(int id, String nombre, String direccion, String telefono, int id_sede) {
        this.id = id;
        this.nombre = nombre;
        this.direccion = direccion;
        this.telefono = telefono;
        this.id_sede = id_sede;
    }

    @Override
    public String toString() {
        return "ID - " + id + "  - " + nombre + " -" ;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public int getId_sede() {
        return id_sede;
    }

    public void setId_sede(int id_sede) {
        this.id_sede = id_sede;
    }
    
    
}
