use baseColegio;

-- 1) cuántos alumnos tiene cada filial?


select      f.nombre 'Filial',
            count(a.id) 'Cantidad de alumnos'	
from        filiales f
join        alumnos a on (f.id = a.id_filial)
group by    f.nombre
order by    f.nombre;

select * from alumnos;


-- 2) cuáles son los nombres y apellidos de los alumnos de la sede Morón?

select      a.apellido 'Apellido',
            a.nombre 'Nombre',
            s.nombre 'Sede'
from        alumnos a
join        filiales f  on (a.id_filial = f.id)
join        sedes s on (s.id = f.id_sede)
where       s.nombre = 'Morón'
order by    a.apellido;	

select * from alumnos;
select * from filiales;
select * from sedes;


-- 3) cuántos cursos existen de Lengua?

select      count(c.id) 'Cantidad de cursos',
            m.nombre 'Materia'
from        cursos c
join        materias m on (c.id_materia = m.id)
where       m.nombre = 'Lengua';

select * from materias;
select * from cursos;



-- 4) cuáles son los nombres, apellidos, sedes y materias que dicta cada profesor?

select      p.apellido Apellido,
            p.nombre Nombre,					
            s.nombre Sede,
            m.nombre
from        profesores p
join        filiales f on (p.id_filial = f.id)
join        sedes s on (s.id = f.id_sede)
join        profes_materias pm on (pm.id_profesor = p.id )
join        materias m on (m.id = pm.id_materia)
order by    p.apellido;	

select * from profesores;
select * from filiales;
select * from sedes;
select * from profes_materias;
select * from materias;



-- 5) cuántos cursos tiene cada filial?

select      count(c.id) 'Cantidad de cursos',
            f.nombre 'Filial'
from        cursos c
join        filiales f on (c.id_filial = f.id)
group by    f.nombre;

select * from cursos;
select * from filiales;



-- 6) cuál es el alumno más jóven?

select 	timestampdiff(year,fechaNac,curdate()) edad,
 	nombre, apellido
from    alumnos
where   fechaNac = ( select max(fechaNac) from alumnos);

select * from alumnos;




-- 7) cuál es el alumno más viejo?

select 	timestampdiff(year,fechaNac,curdate()) edad,
 	nombre, apellido
from    alumnos
where   fechaNac = ( select min(fechaNac) from alumnos);

select * from alumnos;




-- 8) cuántos profesores dictan lengua?

select      count(p.id) 'Cantidad de profesores'
from        profesores p
join        profes_materias pf on (p.id = pf.id_profesor)
join        materias m on (m.id = pf.id_materia)
where       m.nombre = 'Lengua'; 

select * from profesores;
select * from profes_materias;
select * from materias;




-- 9) qué curso es el que tiene más alumnos?

select c.*, count(*) 'Cantidad de cursos' from cursos c join alumnos a
    on c.id = a.id_curso
    group by c.id having 'Cantidad de cursos' =
    (select count(*) 'Cantidad de cursos' from cursos c join alumnos a
    on c.id = a.id_curso group by c.id order by 'Cantidad de cursos' desc limit 1);

select * from cursos;
select * from alumnos;



-- 10) qué curso es el que tiene menos alumnos?

select c.*, count(*) cantidad from cursos c join alumnos a
    on c.id = a.id_curso
    group by c.id having cantidad =
    (select count(*) cantidad from cursos c join alumnos a
    on c.id = a.id_curso group by c.id order by cantidad limit 1);

select * from cursos;
select * from alumnos;


