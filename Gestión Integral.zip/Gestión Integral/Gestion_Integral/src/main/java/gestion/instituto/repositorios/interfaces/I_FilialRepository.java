package gestion.instituto.repositorios.interfaces;

import gestion.instituto.entities.Filial;
import gestion.instituto.entities.Sede;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public interface I_FilialRepository {
    void save(Filial filial);
    void remove(Filial filial);
    void update(Filial filial);
    List<Filial>getAll();
    default Filial getById(int id){
        return getAll()
                .stream()
                .filter(f->f.getId()==id)
                .findFirst()
                .orElse(new Filial());
    }
    default List<Filial> getLikeId(Integer id){
        if(id==null) return new ArrayList<Filial>();
        return getAll()
                .stream()
                .filter(f->f.getId()==id)
                .collect(Collectors.toList());
    }
    default List<Filial> getLikeNombre(String nombre){
        if(nombre==null) return new ArrayList<Filial>();
        return getAll()
                .stream()
                .filter(f->f.getNombre().toLowerCase().contains(nombre.toLowerCase()))
                .collect(Collectors.toList());
    }
    default List<Filial> getById_Sede(Integer id_sede){
        if(id_sede==null) return new ArrayList<Filial>();
        return getAll()
                .stream()
                .filter(f->f.getId_sede()==id_sede)
                .collect(Collectors.toList());
    }
    default List<Filial> getBySede(Sede sede){
        if(sede==null) return new ArrayList<Filial>();
        return getAll()
                .stream()
                .filter(f->f.getId_sede()==sede.getId())
                .collect(Collectors.toList());
    }
}
