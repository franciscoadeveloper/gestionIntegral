package gestion.instituto.enumerados;
public enum Dia {lunesymiercoles("lunes y miercoles"),martesyjueves("martes y jueves"),sabados("sabados");
    private final String diaSemana;
    private Dia(String diaSemana) {this.diaSemana = diaSemana;}
    public String getDiaSemana(){ return diaSemana;}
    @Override
    public String toString() {
        return diaSemana;}
    
    }
