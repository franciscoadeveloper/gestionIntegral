package gestion.instituto.repositorios.jdbc;

import gestion.instituto.entities.Materia;
import gestion.instituto.enumerados.Nivel;
import gestion.instituto.repositorios.interfaces.I_MateriaRepository;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class MateriaRepository implements I_MateriaRepository {

    private Connection conn;

    public MateriaRepository(Connection conn) {this.conn = conn;}

    @Override
    public void save(Materia materia) {
        if(materia==null) return;       
        try (PreparedStatement ps=conn.prepareStatement(
                "insert into materias (nombre,nivel) values (?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, materia.getNombre());
            ps.setString(2, materia.getNivel().getNumNivel());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) materia.setId(rs.getInt(1));
        } catch (Exception e) {e.printStackTrace();}
    }

    @Override
    public void remove(Materia materia) {
        if (materia==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
                "delete from materias where id=?")) {
            ps.setInt(1, materia.getId());
            ps.execute();
        } catch (Exception e) {e.printStackTrace();}
    }

    @Override
    public void update(Materia materia) {
        if (materia==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
                "update materias set nombre=?, nivel=? where id=?")) {
            ps.setString(1, materia.getNombre());
            ps.setString(2, materia.getNivel().getNumNivel());
            ps.setInt(3, materia.getId());
            ps.execute();
        } catch (Exception e) {e.printStackTrace();}
    }

    @Override
    public List<Materia>getAll() {
        List<Materia> list=new ArrayList();
        try (ResultSet rs=conn.createStatement().
                executeQuery("select * from materias")) {
            while(rs.next()) {
                list.add(new Materia(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        Nivel.valueOf("nivel" + rs.getString("nivel"))));
            }

        } catch (Exception e) {e.printStackTrace();}
        return list;
    }

}
