package gestion.instituto.test;

import gestion.instituto.connector.Connector;
import gestion.instituto.entities.Sede;
import gestion.instituto.repositorios.interfaces.I_SedeRepository;
import gestion.instituto.repositorios.jdbc.SedeRepository;
import java.sql.Connection;

public class Test_SedeRepository {
    public static void main(String[] args) {
        try (Connection conn=Connector.getConnection()){
            
            I_SedeRepository sr=new SedeRepository(conn);
            
            System.out.println("\n INICIO DEL Test_SedeRepository \n");
            
            System.out.println("*********************\n");
            System.out.println("Muestro todos los registros con el método 'getAll':\n");
            sr.getAll().forEach(System.out::println);
            System.out.println("\n*********************\n\n");
            
                        
            
            System.out.println("*********************\n");
            System.out.println("Inserto las sedes 'Almagro' y 'Chacarita'"
                    + " con el método 'save':\n");
            Sede sede1=new Sede("Almagro", "Medrano 200", "49726597");
            sr.save(sede1);
            System.out.println(sede1);
            Sede sede2=new Sede("Chacarita", "Alvear 1532", "22835938");
            sr.save(sede2);
            System.out.println(sede2+"\n\n*********************\n\n");
                        
                        
            
            System.out.println("*********************\n");
            System.out.println("Busco la sede de id=2 con el método 'getById': \n");
            System.out.println(sr.getById(2)+"\n\n*********************\n\n");
            
                        
            
            System.out.println("*********************\n");
            System.out.println("Elimino la sede de id=5 con el método 'remove': \n");
            sr.remove(sr.getById(5));
            sr.getAll().forEach(System.out::println);
            System.out.println("\n*********************\n\n");
            
            
            
            System.out.println("*********************\n");
            System.out.println("Actualizo la dirección de la sede de id=1 a 'Belgrano 152'"
                    + "con el método 'update':\n");
            sede2 = sr.getById(1);
            sede2.setNombre("Morón");
            sede2.setDireccion("Belgrano 152");
            sede2.setTelefono("46277486");
            sr.update(sede2);
            System.out.println(sede2+"\n\n*********************\n\n");
            
                        
            
            System.out.println("*********************\n");
            System.out.println("Busco las sedes que tengan como nombre='Morón' "
                    + "con el método 'getLikeNombre':\n");
            sr.getLikeNombre("Morón").forEach(System.out::println);
            System.out.println("\n*********************\n\n");
            
            
            System.out.println("FIN DEL Test_SedeRepository\n");
         
            
        } catch (Exception e) {e.printStackTrace();}
    }
}
