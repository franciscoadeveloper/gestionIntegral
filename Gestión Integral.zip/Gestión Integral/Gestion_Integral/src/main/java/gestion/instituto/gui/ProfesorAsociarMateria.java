package gestion.instituto.gui;

import gestion.instituto.connector.Connector;
import gestion.instituto.entities.Materia;
import gestion.instituto.entities.ProfeMateria;
import gestion.instituto.entities.Profesor;
import gestion.instituto.repositorios.interfaces.I_MateriaRepository;
import gestion.instituto.repositorios.interfaces.I_ProfeMateriaRepository;
import gestion.instituto.repositorios.interfaces.I_ProfesorRepository;
import gestion.instituto.repositorios.jdbc.MateriaRepository;
import gestion.instituto.repositorios.jdbc.ProfeMateriaRepository;
import gestion.instituto.repositorios.jdbc.ProfesorRepository;
import gestion.instituto.util.Table;
import javax.swing.JOptionPane;

public class ProfesorAsociarMateria extends javax.swing.JInternalFrame {
    I_ProfesorRepository pr;
    I_MateriaRepository mr;
    I_ProfeMateriaRepository pm;

    public ProfesorAsociarMateria() {
        super("Formulario de asignación de materias a profesores", false, true, false, true);
        pr=new ProfesorRepository(Connector.getConnection());
        mr=new MateriaRepository(Connector.getConnection());
        pm=new ProfeMateriaRepository(Connector.getConnection());
        initComponents();
        btnEliminar.setVisible(false);
        cargar();
    }
    
    public void cargar(){
        //cargo el JComboBox con la lista de profesores
        cmbProfesor.removeAllItems();
        pr.getAll().forEach(cmbProfesor::addItem);
        
        //cargo el JComboBox con la lista de materias
        cmbMateria.removeAllItems();
        mr.getAll().forEach(cmbMateria::addItem);
        
        //cargo el JTable con todos los objetos de ProfeMateria
        new Table<ProfeMateria>().cargar(tblProfesMaterias, pm.getAll());
        
        btnEliminar.setVisible(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        cmbProfesor = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        cmbMateria = new javax.swing.JComboBox<>();
        btnProfesorBuscar = new javax.swing.JButton();
        btnMateriaBuscar = new javax.swing.JButton();
        betnGuardar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblProfesMaterias = new javax.swing.JTable();
        btnEliminar = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        jLabel1.setText("Profesor:");

        jLabel2.setText("Materia:");

        btnProfesorBuscar.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        btnProfesorBuscar.setText("BUSCAR");
        btnProfesorBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProfesorBuscarActionPerformed(evt);
            }
        });

        btnMateriaBuscar.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        btnMateriaBuscar.setText("BUSCAR");
        btnMateriaBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMateriaBuscarActionPerformed(evt);
            }
        });

        betnGuardar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        betnGuardar.setText("GUARDAR");
        betnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                betnGuardarActionPerformed(evt);
            }
        });

        tblProfesMaterias.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblProfesMaterias.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblProfesMateriasMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblProfesMaterias);

        btnEliminar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnEliminar.setText("ELIMINAR");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jButton1.setText("LIMPIAR BÚSQUEDA");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnEliminar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cmbMateria, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(112, 112, 112)
                        .addComponent(betnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cmbProfesor, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton1)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnMateriaBuscar)
                            .addComponent(btnProfesorBuscar))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbProfesor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnProfesorBuscar))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbMateria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnMateriaBuscar))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(betnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(3, 3, 3)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 389, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGap(110, 110, 110)
                        .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(274, Short.MAX_VALUE))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnProfesorBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProfesorBuscarActionPerformed
        //Evento Buscar Profesor
        btnEliminar.setVisible(false);
        new Table<ProfeMateria>().cargar(tblProfesMaterias, pm.getByProfesor((Profesor) cmbProfesor.getSelectedItem()));
    }//GEN-LAST:event_btnProfesorBuscarActionPerformed

    private void btnMateriaBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMateriaBuscarActionPerformed
        //Evento Buscar Materia
        btnEliminar.setVisible(false);
        new Table<ProfeMateria>().cargar(tblProfesMaterias, pm.getByMateria((Materia) cmbMateria.getSelectedItem()));
    }//GEN-LAST:event_btnMateriaBuscarActionPerformed

    private void betnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_betnGuardarActionPerformed
        //Evento Guardar
        Profesor profesor=(Profesor)cmbProfesor.getSelectedItem();
        Materia materia=(Materia)cmbMateria.getSelectedItem();
        
        ProfeMateria profeMateria = new ProfeMateria(profesor.getId(),materia.getId());
        pm.save(profeMateria);
        JOptionPane.showMessageDialog(this, "Se ha asociado la materia "+materia.getNombre()+
                " al profesor "+profesor.getNombre()+" "+profesor.getApellido()+".");
        cargar();
    }//GEN-LAST:event_betnGuardarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        //Evento Eliminar
        int fila=tblProfesMaterias.getSelectedRow();
        
        ProfeMateria profemateria=pm.getById((Integer)tblProfesMaterias.getValueAt(fila, 0));
        
        pm.remove(profemateria);
        JOptionPane.showMessageDialog(this, "Se ha eliminado la relación correctamente");
        cargar();
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void tblProfesMateriasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblProfesMateriasMouseClicked
        btnEliminar.setVisible(true);
    }//GEN-LAST:event_tblProfesMateriasMouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        cargar();
    }//GEN-LAST:event_jButton1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton betnGuardar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnMateriaBuscar;
    private javax.swing.JButton btnProfesorBuscar;
    private javax.swing.JComboBox<Materia> cmbMateria;
    private javax.swing.JComboBox<Profesor> cmbProfesor;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblProfesMaterias;
    // End of variables declaration//GEN-END:variables
}
