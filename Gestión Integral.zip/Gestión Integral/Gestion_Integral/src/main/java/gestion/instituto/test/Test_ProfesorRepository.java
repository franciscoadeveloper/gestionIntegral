package gestion.instituto.test;

import gestion.instituto.connector.Connector;
import gestion.instituto.entities.Profesor;
import gestion.instituto.repositorios.interfaces.I_ProfesorRepository;
import gestion.instituto.repositorios.jdbc.ProfesorRepository;
import java.sql.Connection;

public class Test_ProfesorRepository {
    public static void main(String[] args) {
        try (Connection conn=Connector.getConnection()){
            
            I_ProfesorRepository pr=new ProfesorRepository(conn);
            
            System.out.println("\n INICIO DEL Test_ProfesorRepository\n");
            
            
            System.out.println("*********************\n");
            System.out.println("Muestro todos los profesores con el método 'getAll':\n");
            pr.getAll().forEach(System.out::println);
            System.out.println("\n*********************\n\n");
                        
            
            System.out.println("*********************\n");
            System.out.println("Inserto los profesores 'Beatriz Genez' y 'Guillermo Masuyama'"
                    + " con el método 'save':\n");
            Profesor profesor1=new Profesor("Beatriz", "Genez", "22358943", "21223589431",
                    "1526465531", "46522987", "betygenez@gmail.com", 3);
            pr.save(profesor1);
            System.out.println(profesor1);
            Profesor profesor2=new Profesor("Guillermo", "Masuyama", "22417943", "20224179430",
                    "1523335533", "47729987", "guillemasuyama@gmail.com", 3);
            pr.save(profesor2);
            System.out.println(profesor2+"\n\n*********************\n\n");
            
            
            System.out.println("*********************\n");
            System.out.println("Busco el profesor de id=5 con el método 'getById':\n");
            System.out.println(pr.getById(5)+"\n\n*********************\n\n");
            
            
            System.out.println("*********************\n");
            System.out.println("Borro el profesor de id=6 con el método 'remove':\n");
            pr.remove(pr.getById(6));
            pr.getAll().forEach(System.out::println);
            System.out.println("\n*********************\n\n");
            
            
            System.out.println("*********************\n");
            System.out.println("Actualizo el nombre del profesor con id=4 a "
                    + "'Ariel Fernández' con el método 'update':\n");
            profesor2 = pr.getById(4);
            profesor2.setNombre("Ariel");
            profesor2.setApellido("Fernández");
            profesor2.setDni("20493051");
            profesor2.setCuil("20204930510");
            profesor2.setCelular("1193002468");
            profesor2.setTelefonoFijo("48779856");
            profesor2.setEmail("arielfernandez@gmail.com");
            profesor2.setId_filial(4);
            pr.update(profesor2);
            pr.getAll().forEach(System.out::println);
            System.out.println("\n*********************\n\n");
            
            
            System.out.println("*********************\n");
            System.out.println("Busco los profesores que se llamen 'Guillermo' "
                    + "con el método 'getLikeNombre':\n");
            pr.getLikeNombre("Guillermo").forEach(System.out::println);
            System.out.println("\n*********************\n\n");
            
            
            System.out.println("*********************\n");
            System.out.println("Busco los profesores que se apelliden 'Fernández' "
                    + "con el método 'getLikeApellido':\n");
            pr.getLikeApellido("Fernández").forEach(System.out::println);
            System.out.println("\n*********************\n\n");
            
            
            System.out.println("*********************\n");
            System.out.println("Busco los profesores cuyo DNI comience con '19' "
                    + "con el método 'getLikeDniEmpiezaCon':\n");
            pr.getLikeDniEmpiezaCon("19").forEach(System.out::println);
            System.out.println("\n*********************\n\n");
            
            
            System.out.println("*********************\n");
            System.out.println("Busco los profesores cuyo DNI contenga '56' "
                    + "con el método 'getLikeDni':\n");
            pr.getLikeDni("56").forEach(System.out::println);
            System.out.println("\n*********************\n\n");
            
            
            System.out.println("*********************\n");
            System.out.println("Busco los profesores de id_filial=3 "
                    + "con el método 'getById_filial':\n"); 
            pr.getById_filial(3).forEach(System.out::println);
            System.out.println("\n*********************\n\n");
            
            
            System.out.println("FIN DEL Test_ProfesorRepository\n\n");
            
        } catch (Exception e) {e.printStackTrace();}
    }
}
