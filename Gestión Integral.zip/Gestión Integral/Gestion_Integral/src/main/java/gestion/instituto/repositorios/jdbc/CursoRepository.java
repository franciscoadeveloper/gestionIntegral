package gestion.instituto.repositorios.jdbc;

import gestion.instituto.entities.Curso;
import gestion.instituto.enumerados.Dia;
import gestion.instituto.enumerados.Horario;
import gestion.instituto.repositorios.interfaces.I_CursoRepository;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class CursoRepository implements I_CursoRepository{
    
    private Connection conn;

    public CursoRepository(Connection conn) {this.conn = conn;}    

    @Override
    public void save(Curso curso) {
        if(curso==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
        "insert into cursos (id_profesor,dia,horario,id_filial,id_materia) "
                + "values (?,?,?,?,?)",PreparedStatement.RETURN_GENERATED_KEYS)){
            ps.setInt(1, curso.getId_profesor());
            ps.setString(2, curso.getDia().getDiaSemana());
            ps.setString(3, curso.getHorario().getHorarioCurso());
            ps.setInt(4, curso.getId_filial());
            ps.setInt(5, curso.getId_materia());
            ps.execute();
            ResultSet rs=ps.getGeneratedKeys();
            if(rs.next()) curso.setId(rs.getInt(1));            
        } catch (Exception e) {e.printStackTrace();}
    }

    @Override
    public void remove(Curso curso) {
        if(curso==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
        "delete from cursos where id=?")){
            ps.setInt(1, curso.getId());
            ps.execute();
        } catch (Exception e) {e.printStackTrace();}
    }

    @Override
    public void update(Curso curso) {
        if(curso==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
        "update cursos set id_profesor=?, dia=?, horario=?, id_filial=?, "
                + "id_materia=? where id=?")){
            ps.setInt(1, curso.getId_profesor());
            ps.setString(2, curso.getDia().getDiaSemana());
            ps.setString(3, curso.getHorario().getHorarioCurso());
            ps.setInt(4, curso.getId_filial());
            ps.setInt(5, curso.getId_materia());
            ps.setInt(6, curso.getId());
            ps.execute();
        } catch (Exception e) {e.printStackTrace();}
    }

    @Override
    public List<Curso> getAll() {
        List<Curso> list=new ArrayList<Curso>();        
        try (ResultSet rs=conn.createStatement().executeQuery(
        "select * from cursos")){                       
            while(rs.next()){
                String horario=rs.getString("horario"); 
                switch (horario) {
                case "18 a 19,30hs.":horario="primerHorario"; break;
                case "19,30 a 21hs.":horario="segundoHorario"; break;
                case "9 a 12hs.":horario="sabadoHorario"; break;
                default: horario="horario desconocido"; break;
            }
                list.add(new Curso(
                rs.getInt("id"),
                rs.getInt("id_profesor"),               
                Dia.valueOf(rs.getString("dia").replace(" ", "")),
                Horario.valueOf(horario),
                rs.getInt("id_filial"),
                rs.getInt("id_materia")
                ));
            }
        } catch (Exception e) {e.printStackTrace();}
        return list;
    }
    
}
