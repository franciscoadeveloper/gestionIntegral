package gestion.instituto.repositorios.jdbc;

import gestion.instituto.entities.ProfeMateria;
import gestion.instituto.repositorios.interfaces.I_ProfeMateriaRepository;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ProfeMateriaRepository implements I_ProfeMateriaRepository{
    
    private Connection conn;

    public ProfeMateriaRepository(Connection conn) {this.conn = conn;} 
    
    @Override
    public void save(ProfeMateria profeMateria) {
        if(profeMateria==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
        "insert into profes_materias (id_profesor,id_materia) values (?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)){
            ps.setInt(1, profeMateria.getId_profesor());
            ps.setInt(2, profeMateria.getId_materia());
            ps.execute();
            ResultSet rs=ps.getGeneratedKeys();
            if(rs.next()) profeMateria.setId(rs.getInt(1));
        } catch (Exception e) {e.printStackTrace();}
    }

    @Override
    public void remove(ProfeMateria profeMateria) {
        if(profeMateria==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
        "delete from profes_materias where id=?")){
            ps.setInt(1, profeMateria.getId());
            ps.execute();
        } catch (Exception e) {e.printStackTrace();}
    }

    @Override
    public void update(ProfeMateria profeMateria) {
        if(profeMateria==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
        "update profes_materias set id_profesor=?,id_materia=? where id=?")){
            ps.setInt(1, profeMateria.getId_profesor());
            ps.setInt(2, profeMateria.getId_materia());
            ps.setInt(3, profeMateria.getId());
            ps.execute();
        } catch (Exception e) {e.printStackTrace();}
    }

    @Override
    public List<ProfeMateria> getAll() {
        List<ProfeMateria> list=new ArrayList();
        try (ResultSet rs=conn.createStatement().executeQuery(
        "select * from profes_materias")){
            while(rs.next()){
                list.add(new ProfeMateria(
                        rs.getInt("id"), 
                        rs.getInt("id_profesor"),
                        rs.getInt("id_materia")));
            }
            
        } catch (Exception e) {e.printStackTrace();}
        return list;
    }
    
}
