package gestion.instituto.repositorios.interfaces;

import gestion.instituto.entities.Filial;
import gestion.instituto.entities.Profesor;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public interface I_ProfesorRepository {
    void save(Profesor profesor);
    void remove(Profesor profesor);
    void update(Profesor profesor);
    List<Profesor>getAll();
    default Profesor getById(Integer id){
        if(id==null) return new Profesor();
        return getAll()
                .stream()
                .filter(p->p.getId()==id)
                .findFirst()
                .orElse(new Profesor());
    }
    default List<Profesor> getLikeId(Integer id){
        if(id==null) return new ArrayList<Profesor>();
        return getAll()
                .stream()
                .filter(p->p.getId()==id)
                .collect(Collectors.toList());
    }
    default List<Profesor> getLikeNombre(String nombre){
        if(nombre==null) return new ArrayList<Profesor>();
        return getAll()
                .stream()
                .filter(p->p.getNombre().toLowerCase().contains(nombre.toLowerCase()))
                .collect(Collectors.toList());
    }
    default List<Profesor> getLikeApellido(String apellido){
        if(apellido==null) return new ArrayList<Profesor>();
        return getAll()
                .stream()
                .filter(p->p.getApellido().toLowerCase().contains(apellido.toLowerCase()))
                .collect(Collectors.toList());
    }
    default List<Profesor> getLikeDni(String dni){
        if(dni==null) return new ArrayList<Profesor>();
        return getAll()
                .stream()
                .filter(p->p.getDni().contains(dni))
                .collect(Collectors.toList());
    }
    default List<Profesor> getLikeDniEmpiezaCon(String dni){
        if(dni==null) return new ArrayList<Profesor>();
        return getAll()
                .stream()
                .filter(p->p.getDni().startsWith(dni))
                .collect(Collectors.toList());
    }
    default List<Profesor> getById_filial(Integer id_filial){
        if(id_filial==null) return new ArrayList<Profesor>();
        return getAll()
                .stream()
                .filter(p->p.getId_filial()==id_filial)
                .collect(Collectors.toList());
    }
    default List<Profesor> getByFilial(Filial filial){
        if(filial==null) return new ArrayList<Profesor>();
        return getAll()
                .stream()
                .filter(p->p.getId_filial()==filial.getId())
                .collect(Collectors.toList());
    }
}
