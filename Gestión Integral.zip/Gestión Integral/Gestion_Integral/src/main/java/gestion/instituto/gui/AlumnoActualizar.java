package gestion.instituto.gui;

import gestion.instituto.connector.Connector;
import gestion.instituto.entities.Alumno;
import gestion.instituto.entities.Curso;
import gestion.instituto.entities.Filial;
import gestion.instituto.repositorios.interfaces.I_AlumnoRepository;
import gestion.instituto.repositorios.interfaces.I_CursoRepository;
import gestion.instituto.repositorios.interfaces.I_FilialRepository;
import gestion.instituto.repositorios.jdbc.AlumnoRepository;
import gestion.instituto.repositorios.jdbc.CursoRepository;
import gestion.instituto.repositorios.jdbc.FilialRepository;
import gestion.instituto.util.Validator;
import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;

public class AlumnoActualizar extends javax.swing.JInternalFrame {
    I_AlumnoRepository ar;
    I_CursoRepository cr;
    I_FilialRepository fr;
    
    public AlumnoActualizar() {
        super("Formulario para editar datos del alumno", false, true, false, true);        
        initComponents();
        ar= new AlumnoRepository(Connector.getConnection());
        cr=new CursoRepository(Connector.getConnection());
        fr=new FilialRepository(Connector.getConnection());
        cargar();
    }
    public void cargar(){
        int fila=AlumnoBuscar.tblAlumnos.getSelectedRow();
        
        //cargo los JTextField con los datos del alumno a editar traídos desde la JTable
        txtNombre.setText(AlumnoBuscar.tblAlumnos.getValueAt(fila, 1).toString());
        txtApellido.setText(AlumnoBuscar.tblAlumnos.getValueAt(fila, 2).toString());
        txtDni.setText(AlumnoBuscar.tblAlumnos.getValueAt(fila, 3).toString());
        txtCelular.setText(AlumnoBuscar.tblAlumnos.getValueAt(fila, 4).toString());
        txtTelefonoFijo.setText(AlumnoBuscar.tblAlumnos.getValueAt(fila, 5).toString());
        txtEmail.setText(AlumnoBuscar.tblAlumnos.getValueAt(fila, 6).toString());
        txtFechaNac.setText(AlumnoBuscar.tblAlumnos.getValueAt(fila, 7).toString());  
        
        //cargo el JComboBox con la lista de filiales
        cmbFilial.removeAllItems();
        fr.getAll().forEach(cmbFilial::addItem);
        
        //selecciono la filial que tiene el alumno desde el JTable
        Filial filial=fr.getById((Integer)AlumnoBuscar.tblAlumnos.getValueAt(fila, 8));
        cmbFilial.getModel().setSelectedItem(filial);
        
        //cargo el JComboBox con la lista de cursos
        cmbCurso.removeAllItems();
        cr.getAll().forEach(cmbCurso::addItem);
        
        //selecciono el curso que tiene el alumno desde el JTable
        Curso curso=cr.getById((Integer)AlumnoBuscar.tblAlumnos.getValueAt(fila, 9));
        cmbCurso.getModel().setSelectedItem(curso);        
    }    
    
    public boolean validar(){
        if(!new Validator(txtNombre).length(3, 20)) return false;
        if(!new Validator(txtApellido).length(3, 20)) return false;
        if(!new Validator(txtDni).length(8)) return false;
        if(!new Validator(txtDni).isNumeric()) return false;
        if(!new Validator(txtCelular).isNumeric()) return false;
        if(!new Validator(txtCelular).length(10, 15)) return false;
        if(!new Validator(txtTelefonoFijo).isNumeric())return false;
        if(!new Validator(txtTelefonoFijo).length(7, 11))return false;
        if(!new Validator(txtEmail).length(7, 30)) return false;
        if(!new Validator(txtEmail).isEmailContiene("@")) return false;
        if(!new Validator(txtEmail).isEmailContiene(".")) return false;
        if(!new Validator(txtEmail).isEmailNoContiene(" ")) return false;
        if(!new Validator(txtEmail).isEmailNoContiene(",")) return false;
        if(!new Validator(txtEmail).isEmail(txtEmail.getText(), '@')) return false;
        if(!new Validator(txtFechaNac).length(10)) return false;
        if(!new Validator(txtFechaNac).isFechaFormat(txtFechaNac.getText(), '-')) return false;
        if(!new Validator(txtFechaNac).isFechaReal(txtFechaNac.getText())) return false;
        return true;        
    }

        @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        txtCelular = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtTelefonoFijo = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txtFechaNac = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        cmbFilial = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        cmbCurso = new javax.swing.JComboBox<>();
        btnGuardar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();
        lblNombre = new javax.swing.JLabel();
        lblApellido = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        txtNombre = new javax.swing.JTextField();
        lblDni = new javax.swing.JLabel();
        lblCelular = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        lblTelefonoFijo = new javax.swing.JLabel();
        txtApellido = new javax.swing.JTextField();
        lblEmail = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        lblFechaNac = new javax.swing.JLabel();
        txtDni = new javax.swing.JTextField();
        lblFormatoFecha = new javax.swing.JLabel();
        btnVolver = new javax.swing.JButton();

        jLabel4.setText("Celular:");

        txtCelular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCelularActionPerformed(evt);
            }
        });
        txtCelular.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCelularKeyTyped(evt);
            }
        });

        jLabel5.setText("Teléfono fijo:");

        txtTelefonoFijo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTelefonoFijoActionPerformed(evt);
            }
        });
        txtTelefonoFijo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtTelefonoFijoKeyTyped(evt);
            }
        });

        jLabel6.setText("Email:");

        txtEmail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEmailActionPerformed(evt);
            }
        });

        jLabel7.setText("Fecha de nac.:");

        txtFechaNac.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtFechaNacKeyTyped(evt);
            }
        });

        jLabel8.setText("Filial:");

        cmbFilial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbFilialActionPerformed(evt);
            }
        });

        jLabel10.setText("Curso:");

        cmbCurso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbCursoActionPerformed(evt);
            }
        });

        btnGuardar.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        btnGuardar.setText("GUARDAR ");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        btnCancelar.setFont(new java.awt.Font("Tahoma", 1, 20)); // NOI18N
        btnCancelar.setText("CANCELAR");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        lblNombre.setForeground(new java.awt.Color(255, 0, 0));

        lblApellido.setForeground(new java.awt.Color(255, 0, 0));

        jLabel1.setText("Nombre:");

        txtNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNombreActionPerformed(evt);
            }
        });
        txtNombre.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNombreKeyTyped(evt);
            }
        });

        lblDni.setForeground(new java.awt.Color(255, 0, 0));

        lblCelular.setForeground(new java.awt.Color(255, 0, 0));

        jLabel2.setText("Apellido:");
        jLabel2.setMaximumSize(new java.awt.Dimension(42, 14));
        jLabel2.setMinimumSize(new java.awt.Dimension(42, 14));

        lblTelefonoFijo.setForeground(new java.awt.Color(255, 0, 0));

        txtApellido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtApellidoActionPerformed(evt);
            }
        });
        txtApellido.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtApellidoKeyTyped(evt);
            }
        });

        jLabel3.setText("DNI:");

        lblFechaNac.setForeground(new java.awt.Color(255, 0, 0));

        txtDni.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDniActionPerformed(evt);
            }
        });
        txtDni.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDniKeyTyped(evt);
            }
        });

        lblFormatoFecha.setText("↳ (AAAA-MM-DD)");

        btnVolver.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnVolver.setText("VOLVER AL FORMULARIO DE BÚSQUEDA DE ALUMNOS");
        btnVolver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVolverActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(10, 10, 10)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(lblCelular, javax.swing.GroupLayout.PREFERRED_SIZE, 244, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(lblTelefonoFijo, javax.swing.GroupLayout.PREFERRED_SIZE, 251, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(lblFechaNac, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(lblFormatoFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(lblDni, javax.swing.GroupLayout.PREFERRED_SIZE, 244, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtDni, javax.swing.GroupLayout.PREFERRED_SIZE, 343, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtCelular, javax.swing.GroupLayout.PREFERRED_SIZE, 343, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtTelefonoFijo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 343, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtEmail, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 343, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 343, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                    .addComponent(btnGuardar)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(btnCancelar))
                                .addComponent(txtFechaNac, javax.swing.GroupLayout.PREFERRED_SIZE, 343, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(cmbFilial, javax.swing.GroupLayout.PREFERRED_SIZE, 343, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(cmbCurso, javax.swing.GroupLayout.PREFERRED_SIZE, 343, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(10, 10, 10)
                                    .addComponent(lblEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 248, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(lblNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtApellido, javax.swing.GroupLayout.PREFERRED_SIZE, 343, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(lblApellido, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(92, 92, 92))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnVolver)
                .addGap(60, 60, 60))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addComponent(lblNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(3, 3, 3)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtApellido, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addComponent(lblApellido, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(3, 3, 3)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtDni, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addComponent(lblDni, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(3, 3, 3)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCelular, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addComponent(lblCelular, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(3, 3, 3)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTelefonoFijo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addComponent(lblTelefonoFijo, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(3, 3, 3)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addComponent(lblEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(3, 3, 3)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtFechaNac, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, 0)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblFechaNac, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblFormatoFecha))
                .addGap(3, 3, 3)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbFilial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbCurso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addComponent(btnVolver, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(28, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtCelularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCelularActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCelularActionPerformed

    private void txtCelularKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCelularKeyTyped
        char c=evt.getKeyChar();
        if(!Character.isDigit(c) && !(evt.getKeyChar() == KeyEvent.VK_BACK_SPACE))
        {
            evt.consume();
            lblCelular.setText("sólo debe contener números");
        }
        else{lblCelular.setText("");}
    }//GEN-LAST:event_txtCelularKeyTyped

    private void txtTelefonoFijoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTelefonoFijoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTelefonoFijoActionPerformed

    private void txtTelefonoFijoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTelefonoFijoKeyTyped
        char c=evt.getKeyChar();
        if(!Character.isDigit(c) && !(evt.getKeyChar() == KeyEvent.VK_BACK_SPACE))
        {
            evt.consume();
            lblTelefonoFijo.setText("sólo debe contener números");
        }
        else{lblTelefonoFijo.setText("");}
    }//GEN-LAST:event_txtTelefonoFijoKeyTyped

    private void txtEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEmailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEmailActionPerformed

    private void txtFechaNacKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtFechaNacKeyTyped
        char c=evt.getKeyChar();
        if(!Character.isDigit(c) && !(evt.getKeyChar()==KeyEvent.VK_MINUS) && !(evt.getKeyChar() == KeyEvent.VK_BACK_SPACE))
        {
            evt.consume();
            lblFechaNac.setText("sólo debe contener números y '-'");
        }
        else{lblFechaNac.setText("");}
    }//GEN-LAST:event_txtFechaNacKeyTyped

    private void cmbFilialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbFilialActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbFilialActionPerformed

    private void cmbCursoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbCursoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbCursoActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        // Evento Actualizar
        int fila=AlumnoBuscar.tblAlumnos.getSelectedRow();
        if(fila==-1) return;
        
        //creo la variable que contendrá el valor de la ID del alumno
        int id=(Integer)AlumnoBuscar.tblAlumnos.getValueAt(fila, 0);
        
        //creo el objeto de Filial desde lo seleccionado en el JComboBox para extraer su ID y cargarlo en el constructor del Alumno
        Filial filial=(Filial)cmbFilial.getModel().getSelectedItem();
        
        //creo el objeto de Curso desde lo seleccionado en el JComboBox para extraer su ID y cargarlo en el constructor del Alumno
        Curso curso=(Curso)cmbCurso.getModel().getSelectedItem();
        
        if(!validar()) return;
        Alumno alumno = new Alumno(
                id,
                txtNombre.getText(), 
                txtApellido.getText(), 
                txtDni.getText(), 
                txtCelular.getText(),
                txtTelefonoFijo.getText(), 
                txtEmail.getText(), 
                txtFechaNac.getText(),
                filial.getId(),
                curso.getId()
                );
        
        if(alumno.getEdad(alumno.getFechaNac())>=18)
        {
            if(alumno.getEdad(alumno.getFechaNac())<=100)
            {
                ar.update(alumno);
                JOptionPane.showMessageDialog(this, "Se han actualizado correctamente los datos del alumno "+alumno.getNombre()+
                    " "+alumno.getApellido()+" de ID: "+alumno.getId());
            }
            else{JOptionPane.showMessageDialog(this, "El alumno debe tener menos de 100 años "
                    , "ALUMNO FUERA DE RANGO DE EDAD", JOptionPane.ERROR_MESSAGE);}
        }
        else{JOptionPane.showMessageDialog(this, "El alumno debe ser mayor de 18 años "
            , "ALUMNO MENOR DE EDAD", JOptionPane.ERROR_MESSAGE);}
    }//GEN-LAST:event_btnGuardarActionPerformed
    
    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        //Evento Cancelar
        this.dispose();
        AlumnoBuscar alumnosBuscar = new AlumnoBuscar();
        Colegio.desktop.add(alumnosBuscar);
        alumnosBuscar.setVisible(true);
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void txtNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNombreActionPerformed

    private void txtNombreKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNombreKeyTyped
        if (!Character.isLetter(evt.getKeyChar())
            && !(evt.getKeyChar() == KeyEvent.VK_SPACE)
            && !(evt.getKeyChar() == KeyEvent.VK_BACK_SPACE)) 
        {
            evt.consume();
            lblNombre.setText("sólo debe contener letras");
        }
        else {lblNombre.setText("");}
    }//GEN-LAST:event_txtNombreKeyTyped

    private void txtApellidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtApellidoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtApellidoActionPerformed

    private void txtApellidoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtApellidoKeyTyped
        if (!Character.isLetter(evt.getKeyChar())
            && !(evt.getKeyChar() == KeyEvent.VK_SPACE)
            && !(evt.getKeyChar() == KeyEvent.VK_BACK_SPACE)) 
        {
            evt.consume();
            lblApellido.setText("sólo debe contener letras");
        } 
        else {lblApellido.setText("");}
    }//GEN-LAST:event_txtApellidoKeyTyped

    private void txtDniActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDniActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDniActionPerformed

    private void txtDniKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDniKeyTyped
        char c=evt.getKeyChar();
        if(!Character.isDigit(c) && !(evt.getKeyChar() == KeyEvent.VK_BACK_SPACE))
        {
            evt.consume();
            lblDni.setText("sólo debe contener números");
        }
        else{lblDni.setText("");}
    }//GEN-LAST:event_txtDniKeyTyped

    private void btnVolverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVolverActionPerformed
        //Evento volver al menú de búsqueda de alumnos
        this.dispose();
        AlumnoBuscar alumnosBuscar = new AlumnoBuscar();
        Colegio.desktop.add(alumnosBuscar);
        alumnosBuscar.setVisible(true);
    }//GEN-LAST:event_btnVolverActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JButton btnVolver;
    private javax.swing.JComboBox<Curso> cmbCurso;
    private javax.swing.JComboBox<Filial> cmbFilial;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel lblApellido;
    private javax.swing.JLabel lblCelular;
    private javax.swing.JLabel lblDni;
    private javax.swing.JLabel lblEmail;
    private javax.swing.JLabel lblFechaNac;
    private javax.swing.JLabel lblFormatoFecha;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JLabel lblTelefonoFijo;
    private javax.swing.JTextField txtApellido;
    private javax.swing.JTextField txtCelular;
    private javax.swing.JTextField txtDni;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtFechaNac;
    private javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtTelefonoFijo;
    // End of variables declaration//GEN-END:variables
}
