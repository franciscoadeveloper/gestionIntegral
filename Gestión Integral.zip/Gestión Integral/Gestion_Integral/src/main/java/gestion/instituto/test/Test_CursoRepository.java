package gestion.instituto.test;

import gestion.instituto.connector.Connector;
import gestion.instituto.entities.Curso;
import gestion.instituto.enumerados.Dia;
import gestion.instituto.enumerados.Horario;
import gestion.instituto.repositorios.interfaces.I_CursoRepository;
import gestion.instituto.repositorios.jdbc.CursoRepository;
import java.sql.Connection;

public class Test_CursoRepository {
    public static void main(String[] args) {
        try (Connection conn=Connector.getConnection()){
            
            I_CursoRepository cr=new CursoRepository(conn);
            
            System.out.println("\n INICIO DEL Test_CursoRepository\n");
                        
            
            System.out.println("*********************\n");
            System.out.println("Muestro todas los cursos con el método 'getAll':\n");
            cr.getAll().forEach(System.out::println);
            System.out.println("\n*********************\n\n");
                                             
            
            System.out.println("*********************\n");
            System.out.println("Inserto los cursos de 'id_profesor=1 sabados 9 a 12hs' y"
                    + " de 'id_profesor=2 sabados 9 a 12'con el método 'save':\n");
            Curso curso1=new Curso(1, Dia.sabados, Horario.sabadoHorario, 1, 1);
            cr.save(curso1);
            System.out.println(curso1);
            Curso curso2=new Curso(2, Dia.sabados, Horario.sabadoHorario, 2, 2);
            cr.save(curso2);
            System.out.println(curso2+"\n\n*********************\n\n");            
                                               
            
            System.out.println("*********************\n");
            System.out.println("Busco el curso de id=3 con el método 'getById':\n");
            System.out.println(cr.getById(3)+"\n\n*********************\n\n");
                        
           
            System.out.println("Borro el curso de id=7 con el método 'remove':\n");
            cr.remove(cr.getById(7));
            cr.getAll().forEach(System.out::println);
            System.out.println("\n*********************\n\n");
                      
                        
            System.out.println("*********************\n");
            System.out.println("Actualizo el horario del curso con id=3 a "
                    + "'18 a 19,30hs.' con el método 'update':\n");
            curso2 = cr.getById(3);
            curso2.setId_profesor(3);
            curso2.setDia(Dia.martesyjueves);
            curso2.setHorario(Horario.primerHorario);
            curso2.setId_filial(3);
            curso2.setId_materia(2);
            cr.update(curso2);
            cr.getAll().forEach(System.out::println);
            System.out.println("\n*********************\n\n");
            
            
            System.out.println("*********************\n");
            System.out.println("Busco los cursos de id_profesor=1 con el método 'getById_profesor':\n");
            cr.getById_profesor(1).forEach(System.out::println);
            System.out.println("\n*********************\n\n");
            
            
            System.out.println("*********************\n");
            System.out.println("Busco los cursos de id_filial=2 con el método 'getById_filial':\n");
            cr.getById_filial(2).forEach(System.out::println);
            System.out.println("\n*********************\n\n");
            
            
            System.out.println("*********************\n");
            System.out.println("Busco los cursos de id_materia=3 con el método 'getById_materia':\n");
            cr.getById_materia(3).forEach(System.out::println);
            System.out.println("\n*********************\n\n");
            
            
            System.out.println("*********************\n");
            System.out.println("Busco los cursos de los días 'lunes y miercoles' "
                    + "con el método 'getLikeDia':\n");
            cr.getLikeDia(Dia.lunesymiercoles).forEach(System.out::println);
            System.out.println("\n*********************\n\n");
            
            
            System.out.println("*********************\n");
            System.out.println("Busco los cursos de horarios '9 a 12hs.' "
                    + "con el método 'getLikeHorario':\n");
            cr.getLikeHorario(Horario.sabadoHorario).forEach(System.out::println);
            System.out.println("\n*********************\n\n");
            
            
            System.out.println("FIN DEL Test_MateriaRepository\n\n");
            
            
        } catch (Exception e) {e.printStackTrace();}
    }
}
