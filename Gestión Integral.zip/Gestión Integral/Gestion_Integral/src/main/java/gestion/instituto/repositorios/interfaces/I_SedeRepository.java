package gestion.instituto.repositorios.interfaces;

import gestion.instituto.entities.Sede;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public interface I_SedeRepository {
    void save(Sede sede);
    void remove(Sede sede);
    void update(Sede sede);
    List<Sede>getAll();
    
    default Sede getById(Integer id){
        if(id==null) return new Sede();
        return getAll()
                .stream()
                .filter(s->s.getId()==id)
                .findFirst()
                .orElse(new Sede());
    }
    default List<Sede> getLikeId(Integer id){
        if(id==null) return new ArrayList<Sede>();
        return getAll()
                .stream()
                .filter(s->s.getId()==id)
                .collect(Collectors.toList());
    }
    default List<Sede> getLikeNombre(String nombre){
        if(nombre==null) return new ArrayList<Sede>() ;
        return getAll()
                .stream()
                .filter(s->s.getNombre().toLowerCase().contains(nombre.toLowerCase()))
                .collect(Collectors.toList());
    }
    
    
}
