drop database if exists baseColegio;
create database baseColegio;
use  baseColegio;

drop table if exists materias;
create table materias(
    id int auto_increment primary key,
    nombre varchar(25),
    nivel enum ('1','2','3')
);

drop table if exists sedes;
create table sedes(
    id int auto_increment primary key,
    nombre varchar(15) not null,
    direccion varchar(35) not null,
    telefono varchar(11) not null
);

drop table if exists filiales;
create table filiales(
    id int auto_increment primary key,
    nombre varchar(15) not null,
    direccion varchar(35) not null,
    telefono varchar(11) not null,
    id_sede int not null,
    foreign key (id_sede) references sedes (id)
);

drop table if exists profesores;
create table profesores (
    id int auto_increment primary key,
    nombre varchar(20) not null,
    apellido varchar(20) not null,
    dni char(8) not null,
    cuil char(11) not null,
    celular varchar(15) ,
    telefonoFijo varchar(11),
    email varchar(30),
    id_filial int not null,
    foreign key (id_filial) references filiales (id)
);

drop table if exists cursos;
create table cursos(
    id int auto_increment primary key,
    id_profesor int not null,
    dia enum ('lunes y miercoles','martes y jueves','sabados'),
    horario enum ('18 a 19,30hs.','19,30 a 21hs.','9 a 12hs.'),
    id_filial int not null,
    id_materia int not null,
    foreign key (id_profesor) references profesores (id),
    foreign key (id_filial) references filiales (id),
    foreign key (id_materia) references materias (id)
);

drop table if exists alumnos;
create table alumnos(
    id int auto_increment primary key,
    nombre varchar(20) not null,
    apellido varchar(20) not null,
    dni char(8) not null,
    celular varchar(15),
    telefonoFijo varchar(11),
    email varchar(30),
    fechaNac date not null, 
    id_filial int not null,
    id_curso int, 
    foreign key (id_filial) references filiales (id),
    foreign key (id_curso) references cursos (id)
);

drop table if exists profes_materias;
create table profes_materias(
    id int auto_increment primary key,
    id_profesor int not null,
    foreign key (id_profesor) references profesores (id),
    id_materia int not null,
    foreign key (id_materia) references materias (id)
);

show tables;



