package gestion.instituto.gui;

import gestion.instituto.connector.Connector;
import gestion.instituto.entities.Curso;
import gestion.instituto.entities.Filial;
import gestion.instituto.entities.Materia;
import gestion.instituto.entities.Profesor;
import gestion.instituto.enumerados.Dia;
import gestion.instituto.enumerados.Horario;
import gestion.instituto.repositorios.interfaces.I_CursoRepository;
import gestion.instituto.repositorios.interfaces.I_FilialRepository;
import gestion.instituto.repositorios.interfaces.I_MateriaRepository;
import gestion.instituto.repositorios.interfaces.I_ProfesorRepository;
import gestion.instituto.repositorios.jdbc.CursoRepository;
import gestion.instituto.repositorios.jdbc.FilialRepository;
import gestion.instituto.repositorios.jdbc.MateriaRepository;
import gestion.instituto.repositorios.jdbc.ProfesorRepository;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class CursoAlta extends javax.swing.JInternalFrame {
    I_CursoRepository cr;
    I_ProfesorRepository pr;
    I_FilialRepository fr;
    I_MateriaRepository mr;
    
    public CursoAlta() {
        super("Formulario para el alta de cursos", false, true, false, true);  
        pr=new ProfesorRepository(Connector.getConnection());
        fr=new FilialRepository(Connector.getConnection());
        mr=new MateriaRepository(Connector.getConnection());
        cr=new CursoRepository(Connector.getConnection());
        initComponents();
        cargar();
    }
    
    public void cargar(){
        //cargo el JComboBox con todos los objetos de la clase Profesor
        cmbProfesor.removeAllItems();
        pr.getAll().forEach(cmbProfesor::addItem);
        
        //cargo el JComboBox con todos los elementos del enumerado Dia
        cmbDia.removeAllItems();
        for (Dia dia : Dia.values()) {cmbDia.addItem(dia);}
        
        //cargo el JComboBox con todos los elementos del enumerado Horario
        cmbHorario.removeAllItems();
        for (Horario horario : Horario.values()) {cmbHorario.addItem(horario);}
        
        //cargo el JComboBox con todos los objetos de la clase Filial
        cmbFilial.removeAllItems();
        fr.getAll().forEach(cmbFilial::addItem);
        
        //cargo el JComboBox con todos los objetos de la clase Materia
        cmbMateria.removeAllItems();
        mr.getAll().forEach(cmbMateria::addItem);
    }
    
    public void limpiar(){
        cmbProfesor.setSelectedIndex(0);
        cmbDia.setSelectedIndex(0);
        cmbHorario.setSelectedIndex(0);
        cmbFilial.setSelectedIndex(0);
        cmbMateria.setSelectedIndex(0);        
    }

        @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        cmbProfesor = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        cmbDia = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        cmbHorario = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        cmbFilial = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        cmbMateria = new javax.swing.JComboBox<>();
        btnGuardar = new javax.swing.JButton();
        btnCancelar = new javax.swing.JButton();

        jLabel1.setText("Profesor:");

        jLabel2.setText("Día:");

        jLabel3.setText("Horario:");

        jLabel4.setText("Filial:");

        jLabel5.setText("Materia:");

        btnGuardar.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnGuardar.setText("GUARDAR");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        btnCancelar.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnCancelar.setText("CANCELAR");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(31, 31, 31)
                        .addComponent(cmbHorario, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnGuardar)
                        .addGap(29, 29, 29)
                        .addComponent(btnCancelar))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2))
                        .addGap(22, 22, 22)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cmbProfesor, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cmbDia, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel4))
                        .addGap(31, 31, 31)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cmbFilial, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cmbMateria, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(44, 44, 44))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbProfesor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(11, 11, 11)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbDia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(7, 7, 7)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cmbHorario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbFilial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbMateria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(48, 48, 48)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        limpiar();
    }//GEN-LAST:event_btnCancelarActionPerformed

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        //Evento Guardar
        Curso curso = new Curso(
                cmbProfesor.getItemAt(cmbProfesor.getSelectedIndex()).getId() ,
                (Dia) cmbDia.getSelectedItem(), 
                (Horario)cmbHorario.getSelectedItem(),
                cmbFilial.getItemAt(cmbFilial.getSelectedIndex()).getId(),
                cmbMateria.getItemAt(cmbMateria.getSelectedIndex()).getId()
                );
        cr.save(curso);
        JOptionPane.showMessageDialog(this, "El curso ha sido dado de alta correctamente! ID de curso: "+curso.getId());
        cargar();
    }//GEN-LAST:event_btnGuardarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnGuardar;
    private javax.swing.JComboBox<Dia> cmbDia;
    private javax.swing.JComboBox<Filial> cmbFilial;
    private javax.swing.JComboBox<Horario> cmbHorario;
    private javax.swing.JComboBox<Materia> cmbMateria;
    private javax.swing.JComboBox<Profesor> cmbProfesor;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    // End of variables declaration//GEN-END:variables
}
