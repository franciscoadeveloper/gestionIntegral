package gestion.instituto.gui;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Colegio extends javax.swing.JFrame {
    public Colegio() {
        initComponents();
        this.setExtendedState(JFrame.MAXIMIZED_BOTH);        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        desktop = new javax.swing.JDesktopPane();
        jMenuBar1 = new javax.swing.JMenuBar();
        mnuAlumnos = new javax.swing.JMenu();
        mniCargarAlumno = new javax.swing.JMenuItem();
        mniActualizarAlumno = new javax.swing.JMenuItem();
        mniBuscarAlumno = new javax.swing.JMenuItem();
        mniEliminarAlumno = new javax.swing.JMenuItem();
        mnuCursos = new javax.swing.JMenu();
        mniCargarCurso = new javax.swing.JMenuItem();
        mniActualizarCurso = new javax.swing.JMenuItem();
        mniBuscarCurso = new javax.swing.JMenuItem();
        mniEliminarCurso = new javax.swing.JMenuItem();
        mnuFiliales = new javax.swing.JMenu();
        mniCargarFilial = new javax.swing.JMenuItem();
        mniActualizarFilial = new javax.swing.JMenuItem();
        mniBuscarFilial = new javax.swing.JMenuItem();
        mniEliminarFilial = new javax.swing.JMenuItem();
        mnuMaterias = new javax.swing.JMenu();
        mniCargarMateria = new javax.swing.JMenuItem();
        mniActualizarMateria = new javax.swing.JMenuItem();
        mniBuscarMateria = new javax.swing.JMenuItem();
        mniEliminarMateria = new javax.swing.JMenuItem();
        mnuProfesores = new javax.swing.JMenu();
        mniCargarProfesor = new javax.swing.JMenuItem();
        mniActualizarProfesor = new javax.swing.JMenuItem();
        mniAsociarProfesor = new javax.swing.JMenuItem();
        mniBuscarProfesor = new javax.swing.JMenuItem();
        mniEliminarProfesor = new javax.swing.JMenuItem();
        mnuSedes = new javax.swing.JMenu();
        mniCargarSede = new javax.swing.JMenuItem();
        mniActualizarSede = new javax.swing.JMenuItem();
        mniBuscarSede = new javax.swing.JMenuItem();
        mniEliminarSede = new javax.swing.JMenuItem();
        mnuOpciones = new javax.swing.JMenu();
        mniSalir = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout desktopLayout = new javax.swing.GroupLayout(desktop);
        desktop.setLayout(desktopLayout);
        desktopLayout.setHorizontalGroup(
            desktopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 907, Short.MAX_VALUE)
        );
        desktopLayout.setVerticalGroup(
            desktopLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 603, Short.MAX_VALUE)
        );

        mnuAlumnos.setMnemonic('a');
        mnuAlumnos.setText("Alumnos");

        mniCargarAlumno.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.CTRL_MASK));
        mniCargarAlumno.setText("Cargar nuevo alumno");
        mniCargarAlumno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniCargarAlumnoActionPerformed(evt);
            }
        });
        mnuAlumnos.add(mniCargarAlumno);

        mniActualizarAlumno.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.CTRL_MASK));
        mniActualizarAlumno.setText("Actualizar datos de alumno");
        mniActualizarAlumno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniActualizarAlumnoActionPerformed(evt);
            }
        });
        mnuAlumnos.add(mniActualizarAlumno);

        mniBuscarAlumno.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_B, java.awt.event.InputEvent.CTRL_MASK));
        mniBuscarAlumno.setText("Buscar alumno");
        mniBuscarAlumno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniBuscarAlumnoActionPerformed(evt);
            }
        });
        mnuAlumnos.add(mniBuscarAlumno);

        mniEliminarAlumno.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_D, java.awt.event.InputEvent.CTRL_MASK));
        mniEliminarAlumno.setText("Dar de baja alumno");
        mniEliminarAlumno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniEliminarAlumnoActionPerformed(evt);
            }
        });
        mnuAlumnos.add(mniEliminarAlumno);

        jMenuBar1.add(mnuAlumnos);

        mnuCursos.setMnemonic('c');
        mnuCursos.setText("Cursos");

        mniCargarCurso.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.CTRL_MASK));
        mniCargarCurso.setText("Cargar nuevo curso");
        mniCargarCurso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniCargarCursoActionPerformed(evt);
            }
        });
        mnuCursos.add(mniCargarCurso);

        mniActualizarCurso.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.CTRL_MASK));
        mniActualizarCurso.setText("Actualizar datos de curso");
        mniActualizarCurso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniActualizarCursoActionPerformed(evt);
            }
        });
        mnuCursos.add(mniActualizarCurso);

        mniBuscarCurso.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_B, java.awt.event.InputEvent.CTRL_MASK));
        mniBuscarCurso.setText("Buscar curso");
        mniBuscarCurso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniBuscarCursoActionPerformed(evt);
            }
        });
        mnuCursos.add(mniBuscarCurso);

        mniEliminarCurso.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_D, java.awt.event.InputEvent.CTRL_MASK));
        mniEliminarCurso.setText("Dar de baja curso");
        mniEliminarCurso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniEliminarCursoActionPerformed(evt);
            }
        });
        mnuCursos.add(mniEliminarCurso);

        jMenuBar1.add(mnuCursos);

        mnuFiliales.setMnemonic('f');
        mnuFiliales.setText("Filiales");

        mniCargarFilial.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.CTRL_MASK));
        mniCargarFilial.setText("Cargar nueva filial");
        mniCargarFilial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniCargarFilialActionPerformed(evt);
            }
        });
        mnuFiliales.add(mniCargarFilial);

        mniActualizarFilial.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.CTRL_MASK));
        mniActualizarFilial.setText("Actualizar datos de filial");
        mniActualizarFilial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniActualizarFilialActionPerformed(evt);
            }
        });
        mnuFiliales.add(mniActualizarFilial);

        mniBuscarFilial.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_B, java.awt.event.InputEvent.CTRL_MASK));
        mniBuscarFilial.setText("Buscar filial");
        mniBuscarFilial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniBuscarFilialActionPerformed(evt);
            }
        });
        mnuFiliales.add(mniBuscarFilial);

        mniEliminarFilial.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_D, java.awt.event.InputEvent.CTRL_MASK));
        mniEliminarFilial.setText("Dar de baja filial");
        mniEliminarFilial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniEliminarFilialActionPerformed(evt);
            }
        });
        mnuFiliales.add(mniEliminarFilial);

        jMenuBar1.add(mnuFiliales);

        mnuMaterias.setMnemonic('m');
        mnuMaterias.setText("Materias");

        mniCargarMateria.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.CTRL_MASK));
        mniCargarMateria.setText("Cargar nueva materia");
        mniCargarMateria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniCargarMateriaActionPerformed(evt);
            }
        });
        mnuMaterias.add(mniCargarMateria);

        mniActualizarMateria.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.CTRL_MASK));
        mniActualizarMateria.setText("Actualizar datos de materia");
        mniActualizarMateria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniActualizarMateriaActionPerformed(evt);
            }
        });
        mnuMaterias.add(mniActualizarMateria);

        mniBuscarMateria.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_B, java.awt.event.InputEvent.CTRL_MASK));
        mniBuscarMateria.setText("Buscar materia");
        mniBuscarMateria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniBuscarMateriaActionPerformed(evt);
            }
        });
        mnuMaterias.add(mniBuscarMateria);

        mniEliminarMateria.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_D, java.awt.event.InputEvent.CTRL_MASK));
        mniEliminarMateria.setText("Dar de baja materia");
        mniEliminarMateria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniEliminarMateriaActionPerformed(evt);
            }
        });
        mnuMaterias.add(mniEliminarMateria);

        jMenuBar1.add(mnuMaterias);

        mnuProfesores.setMnemonic('p');
        mnuProfesores.setText("Profesores");

        mniCargarProfesor.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.CTRL_MASK));
        mniCargarProfesor.setText("Cargar nuevo profesor");
        mniCargarProfesor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniCargarProfesorActionPerformed(evt);
            }
        });
        mnuProfesores.add(mniCargarProfesor);

        mniActualizarProfesor.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.CTRL_MASK));
        mniActualizarProfesor.setText("Actualizar datos de profesor");
        mniActualizarProfesor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniActualizarProfesorActionPerformed(evt);
            }
        });
        mnuProfesores.add(mniActualizarProfesor);

        mniAsociarProfesor.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_M, java.awt.event.InputEvent.CTRL_MASK));
        mniAsociarProfesor.setText("Asociar materia a profesor");
        mniAsociarProfesor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniAsociarProfesorActionPerformed(evt);
            }
        });
        mnuProfesores.add(mniAsociarProfesor);

        mniBuscarProfesor.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_B, java.awt.event.InputEvent.CTRL_MASK));
        mniBuscarProfesor.setText("Buscar profesor");
        mniBuscarProfesor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniBuscarProfesorActionPerformed(evt);
            }
        });
        mnuProfesores.add(mniBuscarProfesor);

        mniEliminarProfesor.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_D, java.awt.event.InputEvent.CTRL_MASK));
        mniEliminarProfesor.setText("Dar de baja profesor");
        mniEliminarProfesor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniEliminarProfesorActionPerformed(evt);
            }
        });
        mnuProfesores.add(mniEliminarProfesor);

        jMenuBar1.add(mnuProfesores);

        mnuSedes.setMnemonic('s');
        mnuSedes.setText("Sedes");

        mniCargarSede.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.CTRL_MASK));
        mniCargarSede.setText("Cargar nueva sede");
        mniCargarSede.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniCargarSedeActionPerformed(evt);
            }
        });
        mnuSedes.add(mniCargarSede);

        mniActualizarSede.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_A, java.awt.event.InputEvent.CTRL_MASK));
        mniActualizarSede.setText("Actualizar datos de sede");
        mniActualizarSede.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniActualizarSedeActionPerformed(evt);
            }
        });
        mnuSedes.add(mniActualizarSede);

        mniBuscarSede.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_B, java.awt.event.InputEvent.CTRL_MASK));
        mniBuscarSede.setText("Buscar sede");
        mniBuscarSede.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniBuscarSedeActionPerformed(evt);
            }
        });
        mnuSedes.add(mniBuscarSede);

        mniEliminarSede.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_D, java.awt.event.InputEvent.CTRL_MASK));
        mniEliminarSede.setText("Dar de baja sede");
        mniEliminarSede.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniEliminarSedeActionPerformed(evt);
            }
        });
        mnuSedes.add(mniEliminarSede);

        jMenuBar1.add(mnuSedes);

        mnuOpciones.setMnemonic('o');
        mnuOpciones.setText("Opciones");

        mniSalir.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_X, java.awt.event.InputEvent.CTRL_MASK));
        mniSalir.setText("Salir");
        mniSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniSalirActionPerformed(evt);
            }
        });
        mnuOpciones.add(mniSalir);

        jMenuBar1.add(mnuOpciones);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(desktop)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(desktop)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void mniBuscarAlumnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniBuscarAlumnoActionPerformed
        AlumnoBuscar ab=new AlumnoBuscar();
        desktop.add(ab);
        ab.setVisible(true);
        
    }//GEN-LAST:event_mniBuscarAlumnoActionPerformed

    private void mniCargarCursoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniCargarCursoActionPerformed
        CursoAlta cursosAlta = new CursoAlta();
        desktop.add(cursosAlta);
        cursosAlta.setVisible(true);
    }//GEN-LAST:event_mniCargarCursoActionPerformed

    private void mniSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniSalirActionPerformed
        System.exit(0);
    }//GEN-LAST:event_mniSalirActionPerformed

    private void mniCargarAlumnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniCargarAlumnoActionPerformed
        AlumnoAlta alumnosCarga = new AlumnoAlta();
        desktop.add(alumnosCarga);
        alumnosCarga.setVisible(true);
    }//GEN-LAST:event_mniCargarAlumnoActionPerformed

    private void mniActualizarAlumnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniActualizarAlumnoActionPerformed
        String ls=System.getProperty("line.separator");
        JOptionPane.showMessageDialog(this, "Para actualizar los datos del alumno primero debe buscarlo desde el menú: "
                + ls+"'Alumno - Buscar alumno'");
    }//GEN-LAST:event_mniActualizarAlumnoActionPerformed

    private void mniEliminarAlumnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniEliminarAlumnoActionPerformed
        String ls=System.getProperty("line.separator");
        JOptionPane.showMessageDialog(this, "Para dar de baja a un alumno primero debe buscarlo desde el menú: "
                + ls+"'Alumno - Buscar alumno'");
    }//GEN-LAST:event_mniEliminarAlumnoActionPerformed

    private void mniActualizarCursoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniActualizarCursoActionPerformed
        String ls=System.getProperty("line.separator");
        JOptionPane.showMessageDialog(this, "Para actualizar los datos del curso primero debe buscarlo desde el menú: "
                + ls+"'Curso - Buscar curso'");
    }//GEN-LAST:event_mniActualizarCursoActionPerformed

    private void mniActualizarFilialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniActualizarFilialActionPerformed
        String ls=System.getProperty("line.separator");
        JOptionPane.showMessageDialog(this, "Para actualizar los datos de la filial primero debe buscarla desde el menú: "
                + ls+"'Filial - Buscar filial'");
    }//GEN-LAST:event_mniActualizarFilialActionPerformed

    private void mniActualizarMateriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniActualizarMateriaActionPerformed
        String ls=System.getProperty("line.separator");
        JOptionPane.showMessageDialog(this, "Para actualizar los datos de la materia primero debe buscarla desde el menú: "
                + ls+"'Materia - Buscar materia'");
    }//GEN-LAST:event_mniActualizarMateriaActionPerformed

    private void mniActualizarProfesorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniActualizarProfesorActionPerformed
        String ls=System.getProperty("line.separator");
        JOptionPane.showMessageDialog(this, "Para actualizar los datos del profesor primero debe buscarlo desde el menú: "
                + ls+"'Profesor - Buscar profesor'");
    }//GEN-LAST:event_mniActualizarProfesorActionPerformed

    private void mniActualizarSedeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniActualizarSedeActionPerformed
        String ls=System.getProperty("line.separator");
        JOptionPane.showMessageDialog(this, "Para actualizar los datos de la sede primero debe buscarla desde el menú: "
                + ls+"'Sede - Buscar sede'");
    }//GEN-LAST:event_mniActualizarSedeActionPerformed

    private void mniEliminarCursoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniEliminarCursoActionPerformed
        String ls=System.getProperty("line.separator");
        JOptionPane.showMessageDialog(this, "Para dar de baja un curso primero debe buscarlo desde el menú: "
                + ls+"'Curso - Buscar curso'");
    }//GEN-LAST:event_mniEliminarCursoActionPerformed

    private void mniEliminarFilialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniEliminarFilialActionPerformed
        String ls=System.getProperty("line.separator");
        JOptionPane.showMessageDialog(this, "Para dar de baja una filial primero debe buscarla desde el menú: "
                + ls+"'Filial - Buscar filial'");
    }//GEN-LAST:event_mniEliminarFilialActionPerformed

    private void mniEliminarMateriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniEliminarMateriaActionPerformed
        String ls=System.getProperty("line.separator");
        JOptionPane.showMessageDialog(this, "Para dar de baja una materia primero debe buscarla desde el menú: "
                + ls+"'Materia - Buscar materia'");
    }//GEN-LAST:event_mniEliminarMateriaActionPerformed

    private void mniEliminarProfesorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniEliminarProfesorActionPerformed
        String ls=System.getProperty("line.separator");
        JOptionPane.showMessageDialog(this, "Para dar de baja a un profesor primero debe buscarlo desde el menú: "
                + ls+"'Profesor - Buscar profesor'");
    }//GEN-LAST:event_mniEliminarProfesorActionPerformed

    private void mniEliminarSedeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniEliminarSedeActionPerformed
        String ls=System.getProperty("line.separator");
        JOptionPane.showMessageDialog(this, "Para dar de baja una sede primero debe buscarla desde el menú: "
                + ls+"'Sede - Buscar sede'");
    }//GEN-LAST:event_mniEliminarSedeActionPerformed

    private void mniBuscarCursoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniBuscarCursoActionPerformed
        CursoBuscar cursosBuscar = new CursoBuscar();
        desktop.add(cursosBuscar);
        cursosBuscar.setVisible(true);
    }//GEN-LAST:event_mniBuscarCursoActionPerformed

    private void mniCargarFilialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniCargarFilialActionPerformed
        FilialAlta filialAlta = new FilialAlta();
        desktop.add(filialAlta);
        filialAlta.setVisible(true);
    }//GEN-LAST:event_mniCargarFilialActionPerformed

    private void mniBuscarFilialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniBuscarFilialActionPerformed
        FilialBuscar filialBuscar = new FilialBuscar();
        desktop.add(filialBuscar);
        filialBuscar.setVisible(true);
    }//GEN-LAST:event_mniBuscarFilialActionPerformed

    private void mniCargarMateriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniCargarMateriaActionPerformed
        MateriaAlta materiaAlta = new MateriaAlta();
        desktop.add(materiaAlta);
        materiaAlta.setVisible(true);
    }//GEN-LAST:event_mniCargarMateriaActionPerformed

    private void mniBuscarMateriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniBuscarMateriaActionPerformed
        MateriaBuscar materiaBuscar = new MateriaBuscar();
        desktop.add(materiaBuscar);
        materiaBuscar.setVisible(true);
    }//GEN-LAST:event_mniBuscarMateriaActionPerformed

    private void mniCargarProfesorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniCargarProfesorActionPerformed
        ProfesorAlta profesorAlta = new ProfesorAlta();
        desktop.add(profesorAlta);
        profesorAlta.setVisible(true);
    }//GEN-LAST:event_mniCargarProfesorActionPerformed

    private void mniBuscarProfesorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniBuscarProfesorActionPerformed
        ProfesorBuscar profesorBuscar = new ProfesorBuscar();
        desktop.add(profesorBuscar);
        profesorBuscar.setVisible(true);
    }//GEN-LAST:event_mniBuscarProfesorActionPerformed

    private void mniAsociarProfesorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniAsociarProfesorActionPerformed
        ProfesorAsociarMateria profesorAsociarMateria = new ProfesorAsociarMateria();
        desktop.add(profesorAsociarMateria);
        profesorAsociarMateria.setVisible(true);
    }//GEN-LAST:event_mniAsociarProfesorActionPerformed

    private void mniCargarSedeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniCargarSedeActionPerformed
        SedeAlta sedeAlta = new SedeAlta();
        desktop.add(sedeAlta);
        sedeAlta.setVisible(true);
    }//GEN-LAST:event_mniCargarSedeActionPerformed

    private void mniBuscarSedeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniBuscarSedeActionPerformed
        SedeBuscar sedeBuscar = new SedeBuscar();
        desktop.add(sedeBuscar);
        sedeBuscar.setVisible(true);
    }//GEN-LAST:event_mniBuscarSedeActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Colegio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Colegio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Colegio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Colegio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Colegio().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JDesktopPane desktop;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem mniActualizarAlumno;
    private javax.swing.JMenuItem mniActualizarCurso;
    private javax.swing.JMenuItem mniActualizarFilial;
    private javax.swing.JMenuItem mniActualizarMateria;
    private javax.swing.JMenuItem mniActualizarProfesor;
    private javax.swing.JMenuItem mniActualizarSede;
    private javax.swing.JMenuItem mniAsociarProfesor;
    private javax.swing.JMenuItem mniBuscarAlumno;
    private javax.swing.JMenuItem mniBuscarCurso;
    private javax.swing.JMenuItem mniBuscarFilial;
    private javax.swing.JMenuItem mniBuscarMateria;
    private javax.swing.JMenuItem mniBuscarProfesor;
    private javax.swing.JMenuItem mniBuscarSede;
    private javax.swing.JMenuItem mniCargarAlumno;
    private javax.swing.JMenuItem mniCargarCurso;
    private javax.swing.JMenuItem mniCargarFilial;
    private javax.swing.JMenuItem mniCargarMateria;
    private javax.swing.JMenuItem mniCargarProfesor;
    private javax.swing.JMenuItem mniCargarSede;
    private javax.swing.JMenuItem mniEliminarAlumno;
    private javax.swing.JMenuItem mniEliminarCurso;
    private javax.swing.JMenuItem mniEliminarFilial;
    private javax.swing.JMenuItem mniEliminarMateria;
    private javax.swing.JMenuItem mniEliminarProfesor;
    private javax.swing.JMenuItem mniEliminarSede;
    private javax.swing.JMenuItem mniSalir;
    private javax.swing.JMenu mnuAlumnos;
    private javax.swing.JMenu mnuCursos;
    private javax.swing.JMenu mnuFiliales;
    private javax.swing.JMenu mnuMaterias;
    private javax.swing.JMenu mnuOpciones;
    private javax.swing.JMenu mnuProfesores;
    private javax.swing.JMenu mnuSedes;
    // End of variables declaration//GEN-END:variables
}
