package gestion.instituto.enumerados;
public enum Horario { primerHorario("18 a 19,30hs."),segundoHorario("19,30 a 21hs."),sabadoHorario("9 a 12hs.");
    private final String horarioCurso;
    private Horario(String horarioCurso) {this.horarioCurso = horarioCurso;}
    public String getHorarioCurso(){return horarioCurso;}
    @Override
    public String toString() {
        return horarioCurso;}    
}
