package gestion.instituto.util;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Validator {
    private JTextField txt;

    public Validator(JTextField txt) {this.txt = txt;}
    
    private boolean error(String message){
        JOptionPane.showMessageDialog(txt, message, "ERROR", JOptionPane.ERROR_MESSAGE);
        txt.selectAll();
        txt.requestFocus();
        return false;
    }
    
    /**
     * Indica la longitud exacta del texto
     * @param length longitud del texto
     * @return true si el texto tiene la longitud del parámetro y false caso contrario.
     */
    public boolean length(int length){
        if(txt.getText().length()==length) return true;
        return error("El campo debe tener "+length+" carcateres obligatoriamente");
    }
    
    /**
     * Indica la longitud mínima y máxima del texto
     * @param min longitud mínima del texto
     * @param max longitud máxima del texto
     * @return true si la longitud está comprendida entre los parámetros establecidos y false caso contrario
     */
    public boolean length(int min,int max){
        if(txt.getText().length()>=min && txt.getText().length()<=max) return true;
        return error("El campo debe contener entre "+min+" y "+max+" caracteres");
    }
    
    /**
     * Valida si el texto ingresado son números
     * @return true si son números y false si no lo son.
     */
    public boolean isNumeric(){
        try {
            Long.parseLong(txt.getText());
            return true;
        } catch (Exception e) {return error("El campo debe ser completado con un números solamente");}
    }
    
    /**
     * Además de validar si es un número entero, valida que esté entre un mínimo y un máximo
     * @param min número entero mínimo permitido
     * @param max número entero máximo permitido
     * @return true si está dentro de los parámetros y false si no lo está.
     */
    public boolean isInteger(int min, int max){
        if(!isNumeric()) return isNumeric();
        int nro=Integer.parseInt(txt.getText());
        if(nro>=min && nro<=max) return true;
        return error("El valor de ser de entre "+min+" y "+max);
    }    
    
    /**
     * Valida que el texto contenga un determinado String
     * @param a String que debe contener la cadena de texto
     * @return true si lo contiene y false si no lo contiene.
     */  
    public boolean isEmailContiene(String a){
        if(txt.getText().contains(a)) return true;
        return error("El mail debe contener: ' "+a+" '");
    }
    
    /**
     * Valida que el texto no contenga un determinado String
     * @param a String que no debe contener la cadena de texto,
     * @return true si no lo contiene y false si lo contiene.
     */
    public boolean isEmailNoContiene(String a){
        if(!txt.getText().contains(a)) return true;
        return error("El mail no puede contener: ' "+a+" '");
    }
    
    /**
     * Valida que una cadena de texto contenga una única vez el caracter pasado como parámetro
     * @param cadena cadena de texto a revisar,
     * @param caracter caracter que debe aparecer en la cadena sólo una vez
     * @return true si aparece una vez y false si aparece más de una vez
     */
    public boolean isEmail(String cadena, char caracter){
        int posicion, contador=0;
        posicion=cadena.indexOf(caracter);
        while(posicion !=-1){
            contador++;
            posicion=cadena.indexOf(caracter,posicion + 1);
        }
        if(contador==1) return true;
        return error("El mail no puede contener más de un '@'");
    }
    
    /**
     * Valida que el texto contenga el caracter pasado como parámetros en las posiciones 4 y 7
     * @param cadena cadena en la que se va a comprobar
     * @param caracter caracter que debe contener en las posiciones 4 y 7
     * @return true si contiene el caracter en las posiciones 4 y 7. False si no los contiene o no están en esas posiciones
     */
   public boolean isFechaFormat(String cadena, char caracter){
       char c=cadena.charAt(4);
       char c2=cadena.charAt(7);       
       if(c==caracter && c2==caracter) return true;
       return error("La fecha debe tener formato de 4 dígitos para el año, \n"
                + "2 dígitos para el mes y 2 dígitos para el día,\n"
                + "separados por '-'");
    }
   
   /**
    * Valida que la fecha ingresada exista, que sea correcta.
    * @param fecha fecha que se va a validar
    * @return true si la fecha ingresada es realmente una fecha existente, false si no lo es.
    */
   public boolean isFechaReal(String fecha) {
        try {
            SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyy-MM-dd");
            formatoFecha.setLenient(false);
            formatoFecha.parse(fecha);
            return true;
        } catch (Exception e) {return error("La fecha debe ser real!");}
        
    }
}
